"""Lõi tấn công TinyA5/1 (known-plaintext + vét cạn 2^23 khóa). Tham số khớp app.py."""
from multiprocessing import Pool, cpu_count

TONG_KHOA = 1 << 23
SO_PHAN = 64  # chia nhỏ để báo tiến độ


def sinh_khoa_dong(k, n, muc_tieu=None):
    x, y, z = k >> 17, (k >> 9) & 0xFF, k & 0x1FF
    out = []
    for i in range(n):
        bx, by, bz = (x >> 4) & 1, (y >> 4) & 1, (z >> 5) & 1
        m = 1 if bx + by + bz >= 2 else 0
        tx = ((x >> 3) ^ (x >> 1) ^ x) & 1
        ty = ((y >> 1) ^ y) & 1
        tz = ((z >> 6) ^ (z >> 1) ^ z) & 1
        if bx == m: x = (x >> 1) | (tx << 5)
        if by == m: y = (y >> 1) | (ty << 7)
        if bz == m: z = (z >> 1) | (tz << 8)
        bit = (x ^ y ^ z) & 1
        if muc_tieu is not None and bit != muc_tieu[i]:
            return None
        out.append(bit)
    return out


def _quet(args):
    lo, hi, s_biet = args
    return [k for k in range(lo, hi) if sinh_khoa_dong(k, len(s_biet), s_biet) is not None]


def vet_can(s_biet, on_progress=None):
    """Duyệt toàn bộ không gian khóa; gọi on_progress(so_khoa_da_xet, chi_so_phan, so_ung_vien_trong_phan) sau mỗi phần."""
    buoc = TONG_KHOA // SO_PHAN
    phan = [(i * buoc, (i + 1) * buoc, s_biet) for i in range(SO_PHAN)]
    kq, xong = [], 0
    with Pool(cpu_count()) as p:
        for idx, ds in enumerate(p.imap(_quet, phan)):  # imap giữ đúng thứ tự phần
            kq.extend(ds)
            xong += buoc
            if on_progress:
                on_progress(xong, idx, len(ds))
    return sorted(kq)


def xor_bits(a, b):
    return [x ^ y for x, y in zip(a, b)]

def text_to_bits(t):
    return [int(c) for b in t.encode() for c in f"{b:08b}"]

def bits_to_text(b):
    return bytes(int("".join(map(str, b[i:i + 8])), 2) for i in range(0, len(b) - 7, 8)).decode(errors="replace")

def s(b):
    return "".join(map(str, b))
