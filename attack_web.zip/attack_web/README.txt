pip install flask
python server.py
# mở http://127.0.0.1:5000
