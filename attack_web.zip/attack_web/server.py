"""Backend Flask cho demo tấn công TinyA5/1.  Chạy: python server.py  rồi mở http://127.0.0.1:5000"""
import threading, time, uuid
from flask import Flask, render_template, request, jsonify
import attack_core as ac

app = Flask(__name__)
JOBS = {}
GIOI_HAN_KIEM_TRA = 20000  # quá nhiều ứng viên thì không kiểm tra từng khóa (chưa thể kết luận)


def chay_job(jid, khoa, tin, n_bit, duoi):
    job = JOBS[jid]
    try:
        K = int(khoa, 2)
        P = ac.text_to_bits(tin)
        C = ac.xor_bits(P, ac.sinh_khoa_dong(K, len(P)))
        n = min(n_bit, len(P))
        s_biet = ac.xor_bits(P[:n], C[:n])
        job['info'] = {
            'khoa': khoa, 'tin': tin, 'C': ac.s(C), 'n_bit': n,
            'p_biet': ac.s(P[:n]),
            'p_biet_text': ac.bits_to_text(P[:n]) if n % 8 == 0 else None,
            's_biet': ac.s(s_biet),
        }
        job['stage'] = 'search'
        t0 = time.time()
        job['tiles'] = [None] * ac.SO_PHAN
        job['tile_size'] = ac.TONG_KHOA // ac.SO_PHAN

        def tien_do(d, idx, cnt):
            job['tiles'][idx] = cnt
            job.update(done=d, elapsed=round(time.time() - t0, 2))

        ung_vien = ac.vet_can(s_biet, tien_do)
        job['elapsed'] = round(time.time() - t0, 2)
        job['so_ung_vien'] = len(ung_vien)

        hop_le, co_kiem_tra = ung_vien, False
        db = ac.text_to_bits(duoi) if duoi else []
        vt = len(P) - len(db)
        job['bo_qua_kiem_tra'] = len(ung_vien) > GIOI_HAN_KIEM_TRA
        if db and tin.endswith(duoi) and vt >= n and not job['bo_qua_kiem_tra']:
            co_kiem_tra = True
            hop_le = [k for k in ung_vien
                      if ac.xor_bits(C, ac.sinh_khoa_dong(k, len(C)))[vt:] == db]
        job['co_kiem_tra'] = co_kiem_tra
        job['so_hop_le'] = len(hop_le)
        job['hop_le'] = [] if job['bo_qua_kiem_tra'] else [{
            'key': format(k, '023b'),
            'plain': ac.bits_to_text(ac.xor_bits(C, ac.sinh_khoa_dong(k, len(C)))),
            'dung': k == K,
        } for k in hop_le[:20]]
        job['khoa_trong_ds'] = K in ung_vien
        job['tile_khoa'] = K // job['tile_size']
        job['stage'] = 'done'
    except Exception as e:
        job['stage'], job['error'] = 'error', str(e)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/start', methods=['POST'])
def start():
    d = request.json or {}
    khoa = d.get('khoa', '').strip()
    tin = d.get('tin', '')
    duoi = d.get('duoi', '')
    try:
        n_bit = int(d.get('n_bit', 32))
    except ValueError:
        return jsonify(error='Số bit biết trước phải là số nguyên.'), 400
    if len(khoa) != 23 or set(khoa) - {'0', '1'}:
        return jsonify(error='Khóa K phải gồm đúng 23 bit nhị phân.'), 400
    if not tin or len(tin) > 100:
        return jsonify(error='Thông điệp phải có từ 1 đến 100 ký tự.'), 400
    if not 1 <= n_bit <= 64:
        return jsonify(error='Số bit biết trước phải từ 1 đến 64.'), 400
    if any(j['stage'] == 'search' for j in JOBS.values()):
        return jsonify(error='Đang có một cuộc tấn công chạy, hãy chờ nó xong.'), 409
    jid = uuid.uuid4().hex[:8]
    JOBS[jid] = {'stage': 'init', 'done': 0, 'total': ac.TONG_KHOA, 'elapsed': 0}
    threading.Thread(target=chay_job, args=(jid, khoa, tin, n_bit, duoi), daemon=True).start()
    return jsonify(job=jid)


@app.route('/api/status/<jid>')
def status(jid):
    return jsonify(JOBS.get(jid) or {'stage': 'error', 'error': 'Không tìm thấy job.'})


if __name__ == '__main__':
    print('Demo tấn công TinyA5/1: http://127.0.0.1:5000')
    app.run(host='127.0.0.1', port=5000, debug=False, threaded=True)
