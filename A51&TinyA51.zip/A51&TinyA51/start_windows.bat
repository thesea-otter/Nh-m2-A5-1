@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
    python run_app.py
) else (
    py -3 run_app.py
)
if errorlevel 1 pause
