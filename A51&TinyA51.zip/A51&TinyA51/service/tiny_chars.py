# -*- coding: utf-8 -*-
"""Chuyển KÝ TỰ <-> chuỗi bit cho chế độ "nhập ký tự" của Tiny A5/1.

Dùng bảng trong slide: bản rõ là các chữ cái của ngôn ngữ 8 chữ cái A..H,
mỗi chữ biểu diễn bằng 3 bit:

    A=000  B=001  C=010  D=011  E=100  F=101  G=110  H=111

Ví dụ: "HEAD" -> 111 100 000 011 -> 111100000011.

Muốn đổi bảng (thêm chữ, đổi mã) chỉ cần sửa ``CHAR_TO_BITS``.
"""

CHAR_TO_BITS = {
    "A": "000", "B": "001", "C": "010", "D": "011",
    "E": "100", "F": "101", "G": "110", "H": "111",
}
BITS_TO_CHAR = {bits: char for char, bits in CHAR_TO_BITS.items()}
BITS_PER_CHAR = 3
ALPHABET = "".join(CHAR_TO_BITS)  # "ABCDEFGH"


def normalize_chars(text: str) -> str:
    """Viết hoa và bỏ khoảng trắng/xuống dòng; ký tự ngoài A..H bị từ chối."""
    if not isinstance(text, str):
        raise TypeError("Ký tự đầu vào phải là chuỗi")
    value = "".join(text.split()).upper()
    invalid = sorted({c for c in value if c not in CHAR_TO_BITS})
    if invalid:
        raise ValueError(
            f"Chỉ được nhập các chữ cái {ALPHABET[0]}–{ALPHABET[-1]}. "
            f"Ký tự không hợp lệ: {invalid}"
        )
    return value


def chars_to_bits(text: str) -> str:
    """Đổi chuỗi chữ cái A..H thành chuỗi bit (3 bit/chữ)."""
    return "".join(CHAR_TO_BITS[c] for c in normalize_chars(text))


def bits_to_chars(bits: str) -> str:
    """Đổi chuỗi bit (độ dài chia hết cho 3) ngược lại thành chữ cái A..H."""
    if len(bits) % BITS_PER_CHAR != 0:
        raise ValueError(
            f"Số bit phải chia hết cho {BITS_PER_CHAR} để đổi ra chữ cái "
            f"(hiện có {len(bits)} bit)"
        )
    return "".join(
        BITS_TO_CHAR[bits[i : i + BITS_PER_CHAR]]
        for i in range(0, len(bits), BITS_PER_CHAR)
    )
