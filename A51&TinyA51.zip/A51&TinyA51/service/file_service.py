# -*- coding: utf-8 -*-
"""Tầng SERVICE cho TỆP: mã hóa/giải mã tệp văn bản .txt (UTF-8).

- Mã hóa: đọc tệp UTF-8 -> mã hóa bằng ``CipherService`` -> Base64 (ASCII) để
  bản mã xem và lưu được dưới dạng tệp .txt.
- Giải mã: đọc Base64 -> giải mã -> khôi phục đúng byte của tệp gốc.

Không phụ thuộc giao diện và không tự ghi gì ra đĩa (việc lưu do tầng UI làm).
Tệp bản mã KHÔNG chứa khóa, tên thuật toán hay số khung: người dùng phải tự
nhớ để giải mã, và không có cơ chế kiểm tra toàn vẹn.
"""

from __future__ import annotations

import base64
import binascii
from dataclasses import dataclass
from typing import BinaryIO, Union

from .cipher_service import CipherService, FrameValidationError, KeyValidationError


class FileCryptoError(ValueError):
    """Lỗi đầu vào xử lý tệp, kèm mã lỗi ổn định để giao diện/test dùng."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class FileCryptoResult:
    """Kết quả xử lý một tệp."""

    filename: str        # tên tệp kết quả đề xuất
    data: bytes          # byte sẽ được ghi ra khi người dùng lưu
    algorithm: str
    operation: str       # "encrypt" hoặc "decrypt"
    input_size: int
    mime_type: str = "text/plain; charset=utf-8"

    @property
    def content(self) -> str:
        """Nội dung kết quả dưới dạng văn bản để hiển thị."""
        return self.data.decode("utf-8")


class FileCipherService:
    """Mã hóa/giải mã tệp .txt UTF-8 (bản mã là Base64 trong tệp .txt)."""

    def __init__(self, cipher: CipherService | None = None,
                 max_plaintext_bytes: int = 64 * 1024):
        if not isinstance(max_plaintext_bytes, int) or max_plaintext_bytes <= 0:
            raise ValueError("max_plaintext_bytes phải là số nguyên dương.")
        self.cipher = cipher or CipherService()
        self.max_plaintext_bytes = max_plaintext_bytes
        # Cho phép Base64 có ngắt dòng, khoảng trắng và BOM từ trình soạn thảo.
        self.max_ciphertext_bytes = 4 * ((max_plaintext_bytes + 2) // 3) + 4096

    # ------------------------------------------------------------------
    def encrypt_file(self, upload: Union[bytes, BinaryIO], filename: str,
                     key_binary: str, algorithm: str = "a5/1",
                     frame: int = 0) -> FileCryptoResult:
        return self.process_file(upload, filename, "encrypt", key_binary, algorithm, frame)

    def decrypt_file(self, upload: Union[bytes, BinaryIO], filename: str,
                     key_binary: str, algorithm: str = "a5/1",
                     frame: int = 0) -> FileCryptoResult:
        return self.process_file(upload, filename, "decrypt", key_binary, algorithm, frame)

    def process_file(self, upload: Union[bytes, BinaryIO], filename: str,
                     operation: str, key_binary: str, algorithm: str = "a5/1",
                     frame: int = 0) -> FileCryptoResult:
        if operation not in ("encrypt", "decrypt"):
            raise FileCryptoError("INVALID_OPERATION", "Chọn encrypt hoặc decrypt.")
        if algorithm not in self.cipher.list_algorithms():
            raise FileCryptoError("INVALID_ALGORITHM", "Thuật toán không tồn tại.")
        try:
            key = self.cipher.key_binary_to_bytes(algorithm, key_binary)
            frame = self.cipher.validate_frame(algorithm, frame)
        except KeyValidationError as exc:
            raise FileCryptoError("INVALID_KEY", str(exc)) from exc
        except FrameValidationError as exc:
            raise FileCryptoError("INVALID_FRAME", str(exc)) from exc

        filename = self._validate_filename(filename)
        limit = self.max_plaintext_bytes if operation == "encrypt" else self.max_ciphertext_bytes
        raw = self._read_upload(upload, limit)

        if operation == "encrypt":
            self._require_utf8(raw, "INVALID_UTF8", "Tệp đầu vào phải là văn bản UTF-8.")
            result = base64.b64encode(self.cipher.encrypt(algorithm, raw, key, frame))
            output_name = filename[:-4] + "_encrypted.txt"
        else:
            try:
                ascii_data = raw.decode("utf-8-sig").encode("ascii")
                cipher_bytes = base64.b64decode(b"".join(ascii_data.split()), validate=True)
            except (UnicodeError, binascii.Error, ValueError) as exc:
                raise FileCryptoError(
                    "INVALID_BASE64", "Tệp giải mã phải chứa bản mã Base64 hợp lệ."
                ) from exc
            if len(cipher_bytes) > self.max_plaintext_bytes:
                raise FileCryptoError(
                    "FILE_TOO_LARGE", "Dữ liệu sau khi đọc Base64 vượt giới hạn cho phép."
                )
            result = self.cipher.encrypt(algorithm, cipher_bytes, key, frame)
            self._require_utf8(
                result, "INVALID_DECRYPTED_UTF8",
                "Kết quả không phải UTF-8. Hãy kiểm tra khóa, số khung, thuật toán và tệp bản mã.",
            )
            stem = filename[:-4]
            if stem.endswith("_encrypted"):
                stem = stem[:-10]
            output_name = stem + "_decrypted.txt"

        return FileCryptoResult(output_name, result, algorithm, operation, len(raw))

    # ------------------------------------------------------------------
    # Kiểm tra đầu vào
    # ------------------------------------------------------------------
    @staticmethod
    def _validate_filename(filename: str) -> str:
        if not isinstance(filename, str):
            raise FileCryptoError("INVALID_FILENAME", "Tên tệp không hợp lệ.")
        filename = filename.replace("\\", "/").rsplit("/", 1)[-1]
        if not filename.lower().endswith(".txt") or not filename[:-4].strip():
            raise FileCryptoError("INVALID_FILE_TYPE", "Chỉ hỗ trợ tệp có phần mở rộng .txt.")
        if any(ord(c) < 32 or ord(c) == 127 for c in filename):
            raise FileCryptoError("INVALID_FILENAME", "Tên tệp chứa ký tự không hợp lệ.")
        return filename

    @staticmethod
    def _require_utf8(data: bytes, code: str, message: str) -> None:
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise FileCryptoError(code, message) from exc

    @staticmethod
    def _read_upload(upload: Union[bytes, BinaryIO], limit: int) -> bytes:
        """Đọc dữ liệu tải lên (bytes hoặc tệp mở ở chế độ 'rb'), có giới hạn dung lượng."""
        if isinstance(upload, bytes):
            data = upload
        elif callable(getattr(upload, "read", None)):
            chunks, count = [], 0
            while count <= limit:
                chunk = upload.read(min(65536, limit + 1 - count))
                if not isinstance(chunk, bytes):
                    raise FileCryptoError("INVALID_UPLOAD", "Tệp phải được đọc ở chế độ nhị phân.")
                if not chunk:
                    break
                chunks.append(chunk)
                count += len(chunk)
            data = b"".join(chunks)
        else:
            raise FileCryptoError("INVALID_UPLOAD", "Cần truyền bytes hoặc tệp mở ở chế độ rb.")
        if len(data) > limit:
            raise FileCryptoError("FILE_TOO_LARGE", f"Tệp vượt giới hạn {limit} byte cho thao tác này.")
        return data
