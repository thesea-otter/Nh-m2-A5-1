# -*- coding: utf-8 -*-
"""Tiny A5/1 - mô hình giảng dạy A5/1 rút gọn với khóa 23 bit.

Tham số (theo bài giảng trên lớp):

- X: 6 bit (x0 .. x5)
- Y: 8 bit (y0 .. y7)
- Z: 9 bit (z0 .. z8)
- Khóa K 23 bit được chia thẳng vào các thanh ghi: K = X || Y || Z
- Bit điều khiển đa số: maj(x1, y3, z3)
- Phản hồi:
    X: x2 XOR x4 XOR x5
    Y: y6 XOR y7
    Z: z2 XOR z7 XOR z8
- Bit ngõ ra sau khi dịch có điều kiện: x5 XOR y7 XOR z8

Tiny A5/1 chỉ là mô hình giảng dạy, KHÔNG phải chuẩn GSM/3GPP. Khác với A5/1
đầy đủ (``a5_1.py``), bản này không có số khung và không có giai đoạn trộn
khóa/khung. Để dùng chung giao diện với A5/1, tham số ``frame`` vẫn được nhận
nhưng bắt buộc bằng 0.

Quy ước đóng gói khóa thành bytes
---------------------------------
Giao diện thuật toán dùng ``bytes`` nên khóa 23 bit được lưu trong 3 byte,
MSB trước, căn trái, thêm 1 bit đệm 0 ở cuối. Ví dụ:

    10010101001110100110000  ->  10010101 00111010 0110000[0]
                                0x95       0x3A       0x60

``CipherService.key_binary_to_bytes()`` tự động đóng gói theo quy ước này.
"""

from typing import List, Tuple

from .base_cipher import StreamCipherAlgorithm


class A5_1_Tiny(StreamCipherAlgorithm):
    """Mô hình Tiny A5/1: khóa 23 bit, thanh ghi X/Y/Z = 6/8/9 bit."""

    name = "a5/1-tiny"
    key_bits = 23
    frame_bits = 0  # Mô hình giảng dạy này không dùng số khung.

    X_LEN = 6
    Y_LEN = 8
    Z_LEN = 9

    KEY_BYTES = 3
    UNUSED_PADDING_BITS = KEY_BYTES * 8 - key_bits  # 1 bit đệm

    @staticmethod
    def _majority(a: int, b: int, c: int) -> int:
        """Hàm đa số của ba bit."""
        return 1 if (a + b + c) >= 2 else 0

    @staticmethod
    def _rotate_x(x: List[int]) -> List[int]:
        """Dịch thanh ghi X với bit phản hồi t = x2 XOR x4 XOR x5."""
        t = x[2] ^ x[4] ^ x[5]
        return [t] + x[:-1]

    @staticmethod
    def _rotate_y(y: List[int]) -> List[int]:
        """Dịch thanh ghi Y với bit phản hồi t = y6 XOR y7."""
        t = y[6] ^ y[7]
        return [t] + y[:-1]

    @staticmethod
    def _rotate_z(z: List[int]) -> List[int]:
        """Dịch thanh ghi Z với bit phản hồi t = z2 XOR z7 XOR z8."""
        t = z[2] ^ z[7] ^ z[8]
        return [t] + z[:-1]

    @classmethod
    def _unpack_key_bits(cls, key: bytes) -> List[int]:
        """Giải mã khóa 23 bit (căn trái) từ đúng 3 byte."""
        if not isinstance(key, (bytes, bytearray)):
            raise TypeError("Khóa Tiny A5/1 phải là bytes hoặc bytearray")
        if len(key) != cls.KEY_BYTES:
            raise ValueError(
                f"Tiny A5/1 cần đúng {cls.key_bits} bit được đóng gói trong "
                f"{cls.KEY_BYTES} byte; nhận được {len(key)} byte"
            )

        # Bit đệm ở cuối byte cuối bắt buộc phải bằng 0.
        padding_mask = (1 << cls.UNUSED_PADDING_BITS) - 1
        if key[-1] & padding_mask:
            raise ValueError(
                "Khóa 23 bit đóng gói sai: bit đệm cuối phải bằng 0. "
                "Hãy dùng CipherService.key_binary_to_bytes() để đóng gói."
            )

        bits: List[int] = []
        for byte_value in key:
            for bit_index in range(7, -1, -1):
                bits.append((byte_value >> bit_index) & 1)
        return bits[: cls.key_bits]

    def _key_setup(self, key: bytes, frame: int = 0) -> Tuple[List[int], List[int], List[int]]:
        """Chia trực tiếp khóa K vào X, Y, Z theo K = X || Y || Z."""
        if frame != 0:
            raise ValueError(
                "Tiny A5/1 không dùng số khung; frame phải bằng 0"
            )

        bits = self._unpack_key_bits(key)
        x = bits[: self.X_LEN]
        y = bits[self.X_LEN : self.X_LEN + self.Y_LEN]
        z = bits[self.X_LEN + self.Y_LEN :]
        return x, y, z

    def _clock_majority(
        self, x: List[int], y: List[int], z: List[int]
    ) -> Tuple[List[int], List[int], List[int]]:
        """Chỉ dịch các thanh ghi có bit điều khiển trùng với maj(x1, y3, z3)."""
        m = self._majority(x[1], y[3], z[3])

        if x[1] == m:
            x = self._rotate_x(x)
        if y[3] == m:
            y = self._rotate_y(y)
        if z[3] == m:
            z = self._rotate_z(z)

        return x, y, z

    @staticmethod
    def _output_bit(x: List[int], y: List[int], z: List[int]) -> int:
        """Bit keystream s_i = x5 XOR y7 XOR z8 (lấy sau khi đã dịch có điều kiện)."""
        return x[5] ^ y[7] ^ z[8]

    def generate_keystream(self, key: bytes, frame: int, num_bits: int) -> List[int]:
        """Sinh ``num_bits`` bit keystream của Tiny A5/1."""
        if not isinstance(num_bits, int) or isinstance(num_bits, bool) or num_bits < 0:
            raise ValueError("num_bits phải là số nguyên không âm")

        x, y, z = self._key_setup(key, frame)
        bits: List[int] = []

        for _ in range(num_bits):
            x, y, z = self._clock_majority(x, y, z)
            bits.append(self._output_bit(x, y, z))

        return bits
