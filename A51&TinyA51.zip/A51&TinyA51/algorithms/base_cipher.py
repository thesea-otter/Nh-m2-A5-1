# -*- coding: utf-8 -*-
"""Giao diện chung cho các thuật toán mã dòng họ A5 (A5/1 đầy đủ và Tiny A5/1).

Mỗi thuật toán cụ thể chỉ cần cài đặt ``generate_keystream``. Việc mã hóa
(và giải mã) khi đó chỉ là phép XOR giữa dữ liệu và dãy keystream.

Lưu ý: vì là mã dòng, mã hóa và giải mã là CÙNG MỘT phép XOR - XOR hai lần
với cùng keystream sẽ trả lại dữ liệu ban đầu.
"""

from abc import ABC, abstractmethod
from typing import List, Tuple


class StreamCipherAlgorithm(ABC):
    """Lớp cơ sở mà A5/1 đầy đủ và Tiny A5/1 cùng kế thừa."""

    name: str = "abstract"   # tên đăng ký trong CipherService
    key_bits: int = 0        # số bit khóa
    frame_bits: int = 0      # số bit của số khung (0 = không dùng)

    @abstractmethod
    def generate_keystream(self, key: bytes, frame: int, num_bits: int) -> List[int]:
        """Trả về ``num_bits`` bit keystream, mỗi bit là 0 hoặc 1."""
        raise NotImplementedError

    @staticmethod
    def _bits_to_bytes(bits: List[int]) -> bytes:
        """Gói danh sách bit thành bytes (MSB trước), byte cuối đệm số 0 nếu thiếu."""
        out = bytearray((len(bits) + 7) // 8)
        for index, bit in enumerate(bits):
            if bit not in (0, 1):
                raise ValueError("Keystream chỉ được chứa bit 0 hoặc 1")
            if bit:
                out[index // 8] |= 0x80 >> (index % 8)
        return bytes(out)

    def keystream_bytes(self, key: bytes, frame: int, num_bits: int) -> bytes:
        """Sinh keystream rồi gói thành bytes (MSB trước)."""
        return self._bits_to_bytes(self.generate_keystream(key, frame, num_bits))

    def encrypt_with_keystream(
        self, plaintext: bytes, key: bytes, frame: int
    ) -> Tuple[bytes, List[int]]:
        """Mã hóa một lần và trả về cả bản mã lẫn keystream đã dùng.

        Trả luôn keystream để tầng service hiển thị/gỡ lỗi mà không phải
        sinh lại cùng một dãy lần thứ hai.
        """
        if not isinstance(plaintext, (bytes, bytearray)):
            raise TypeError("plaintext phải là bytes hoặc bytearray")

        plaintext_bytes = bytes(plaintext)
        keystream_bits = self.generate_keystream(
            key, frame, len(plaintext_bytes) * 8
        )
        keystream_bytes = self._bits_to_bytes(keystream_bits)
        ciphertext = bytes(
            plain_byte ^ key_byte
            for plain_byte, key_byte in zip(plaintext_bytes, keystream_bytes)
        )
        return ciphertext, keystream_bits

    def encrypt(self, plaintext: bytes, key: bytes, frame: int) -> bytes:
        """Mã hóa bytes bằng cách XOR với keystream."""
        ciphertext, _ = self.encrypt_with_keystream(plaintext, key, frame)
        return ciphertext

    def decrypt(self, ciphertext: bytes, key: bytes, frame: int) -> bytes:
        """Giải mã bytes - mã dòng nên giống hệt phép mã hóa."""
        return self.encrypt(ciphertext, key, frame)
