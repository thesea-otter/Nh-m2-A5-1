# -*- coding: utf-8 -*-
"""Điểm khởi chạy ứng dụng: ``python run_app.py``."""

import sys


def main() -> int:
    # Chỉ kiểm tra riêng Tcl/Tk ở bước này, để không nhầm với lỗi import khác.
    try:
        import tkinter as tk
    except ImportError:
        print(
            "Python hiện tại chưa có Tcl/Tk hoạt động.\n"
            "Trên Windows, cài hoặc sửa cài đặt Python và bật thành phần Tcl/Tk.",
            file=sys.stderr,
        )
        return 1

    # Lỗi import của chính ứng dụng (thiếu hàm, sai tên module...) sẽ hiện
    # nguyên traceback thay vì bị báo nhầm là thiếu Tcl/Tk.
    from ui.app import main as launch

    try:
        launch()
    except tk.TclError as exc:
        print(f"Không mở được cửa sổ ứng dụng: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
