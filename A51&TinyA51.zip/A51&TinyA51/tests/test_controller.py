# -*- coding: utf-8 -*-
"""Test bộ điều phối giao diện (không cần Tkinter): các kiểu nhập + chọn/lưu tệp."""

import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from service import FileCryptoError  # noqa: E402
from ui.controller import (  # noqa: E402
    DECRYPT, ENCRYPT, MODE_BINARY, MODE_CHARS, MODE_FILE, MODE_TEXT, CipherController,
)

FULL = "1010" * 16
TINY = "100101.01001110.100110000"


class ModeTests(unittest.TestCase):
    def setUp(self):
        self.c = CipherController()

    def test_tiny_binary_slide_example(self):
        view = self.c.run("a5/1-tiny", MODE_BINARY, ENCRYPT, TINY, "", "111")
        self.assertEqual(view.copy_text, "011")
        self.assertIn("100", view.text)
        self.assertEqual(self.c.run("a5/1-tiny", MODE_BINARY, DECRYPT, TINY, "", "011").copy_text, "111")

    def test_a51_binary_roundtrip_with_frame(self):
        enc = self.c.run("a5/1", MODE_BINARY, ENCRYPT, FULL, "7", "1011 0010")
        dec = self.c.run("a5/1", MODE_BINARY, DECRYPT, FULL, "7", enc.copy_text)
        self.assertEqual(dec.copy_text, "10110010")

    def test_a51_binary_ciphertext_also_displays_plaintext_text(self):
        plaintext = "Xin chào"
        bits = self.c.cipher.text_to_binary(plaintext)
        enc = self.c.run("a5/1", MODE_BINARY, ENCRYPT, FULL, "3", bits)
        dec = self.c.run("a5/1", MODE_BINARY, DECRYPT, FULL, "3", enc.copy_text)
        self.assertIn("Bản rõ (văn bản UTF-8):\nXin chào", dec.text)
        self.assertEqual(dec.copy_text, bits)

    def test_a51_text_roundtrip(self):
        enc = self.c.run("a5/1", MODE_TEXT, ENCRYPT, FULL, "3", "Xin chào")
        dec = self.c.run("a5/1", MODE_TEXT, DECRYPT, FULL, "3", enc.copy_text)
        self.assertEqual(dec.copy_text, "Xin chào")

    def test_a51_hex_input_selected_explicitly(self):
        enc = self.c.run("a5/1", MODE_TEXT, ENCRYPT, FULL, "3", "Xin chào")
        dec = self.c.run("a5/1", MODE_BINARY, DECRYPT, FULL, "3", enc.copy_text,
                         ciphertext_format="hex")
        self.assertEqual(dec.copy_text, "Xin chào")

    def test_a51_binary_input_selected_explicitly(self):
        enc = self.c.run("a5/1", MODE_BINARY, ENCRYPT, FULL, "3", "10110010")
        dec = self.c.run("a5/1", MODE_TEXT, DECRYPT, FULL, "3", enc.copy_text,
                         ciphertext_format="binary")
        self.assertEqual(dec.copy_text, "10110010")

    def test_tiny_chars_roundtrip(self):
        enc = self.c.run("a5/1-tiny", MODE_CHARS, ENCRYPT, TINY, "", "HEAD")
        dec = self.c.run("a5/1-tiny", MODE_CHARS, DECRYPT, TINY, "", enc.copy_text)
        self.assertEqual(dec.copy_text, "HEAD")

    def test_tiny_ignores_frame_text(self):
        view = self.c.run("a5/1-tiny", MODE_BINARY, ENCRYPT, TINY, "999", "111")
        self.assertEqual(view.copy_text, "011")

    def test_empty_input_and_bad_values(self):
        with self.assertRaises(ValueError):
            self.c.run("a5/1", MODE_BINARY, ENCRYPT, FULL, "0", "  ")
        with self.assertRaises(ValueError):
            self.c.run("a5/1", MODE_TEXT, ENCRYPT, FULL, "0", "")
        with self.assertRaises(ValueError):
            self.c.run("a5/1", MODE_BINARY, ENCRYPT, "101", "0", "1")      # khóa sai
        with self.assertRaises(ValueError):
            self.c.run("a5/1", MODE_BINARY, ENCRYPT, FULL, "abc", "1")     # số khung sai
        with self.assertRaises(ValueError):
            self.c.run("a5/1", MODE_BINARY, "other", FULL, "0", "1")


class FileFlowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.controller = CipherController()
        self.original = b"\xef\xbb\xbf" + "Xin chào Việt Nam!\r\n\r\n  cuối dòng  \n".encode()
        self.source = self.folder / "tài liệu gốc.txt"
        self.source.write_bytes(self.original)

    def assert_error(self, code, callback):
        with self.assertRaises(FileCryptoError) as raised:
            callback()
        self.assertEqual(raised.exception.code, code)

    def run_file(self, operation, algorithm="a5/1", key=FULL, frame="5"):
        return self.controller.run(algorithm, MODE_FILE, operation, key, frame, "")

    def test_select_encrypt_save_select_decrypt_save(self):
        self.controller.select_file(self.source)
        enc = self.run_file(ENCRYPT)
        enc_path = self.folder / "enc.txt"
        self.assertEqual(self.controller.save_result(enc_path), enc_path)
        self.assertEqual(enc_path.read_bytes(), enc.file_result.data)
        self.controller.select_file(enc_path)
        self.assertIsNone(self.controller.result)
        dec = self.run_file(DECRYPT)
        dec_path = self.folder / "dec.txt"
        self.controller.save_result(dec_path)
        self.assertEqual(dec_path.read_bytes(), self.original)
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_tiny_can_also_process_files(self):
        self.controller.select_file(self.source)
        enc = self.run_file(ENCRYPT, "a5/1-tiny", TINY, "")
        self.controller.save_result(self.folder / "t.txt")
        self.controller.select_file(self.folder / "t.txt")
        self.assertEqual(self.run_file(DECRYPT, "a5/1-tiny", TINY, "").file_result.data, self.original)

    def test_select_invalid_file_and_missing_file(self):
        self.assert_error("FILE_NOT_FOUND", lambda: self.controller.select_file(self.folder / "missing.txt"))
        bad = self.folder / "a.pdf"
        bad.write_bytes(b"example")
        self.assert_error("INVALID_FILE_TYPE", lambda: self.controller.select_file(bad))

    def test_process_requires_selection(self):
        self.assert_error("MISSING_FILE", lambda: self.run_file(ENCRYPT))

    def test_save_requires_current_result(self):
        self.assert_error("NO_RESULT", lambda: self.controller.save_result(self.folder / "out.txt"))

    def test_failed_processing_discards_old_result(self):
        self.controller.select_file(self.source)
        self.run_file(ENCRYPT)
        self.assert_error("INVALID_KEY", lambda: self.run_file(ENCRYPT, key="101"))
        self.assertIsNone(self.controller.result)

    def test_save_keeps_source_unchanged(self):
        self.controller.select_file(self.source)
        self.run_file(ENCRYPT)
        self.assert_error("SOURCE_OVERWRITE", lambda: self.controller.save_result(self.source))
        self.assertEqual(self.source.read_bytes(), self.original)

    def test_save_blocks_alias_of_source(self):
        alias = self.folder / "alias.txt"
        try:
            alias.hardlink_to(self.source)
        except OSError:
            self.skipTest("Hệ thống tệp không hỗ trợ hard link")
        self.controller.select_file(self.source)
        self.run_file(ENCRYPT)
        self.assert_error("SOURCE_OVERWRITE", lambda: self.controller.save_result(alias))

    def test_saved_extension_must_be_txt(self):
        self.controller.select_file(self.source)
        self.run_file(ENCRYPT)
        self.assert_error("INVALID_FILE_TYPE", lambda: self.controller.save_result(self.folder / "out.pdf"))
        self.assertFalse((self.folder / "out.pdf").exists())

    def test_atomic_save_does_not_damage_existing_file_on_failure(self):
        target = self.folder / "existing.txt"
        target.write_bytes(b"existing data")
        self.controller.select_file(self.source)
        self.run_file(ENCRYPT)
        with patch("ui.controller.os.replace", side_effect=PermissionError("khóa tệp")):
            with self.assertRaises(PermissionError):
                self.controller.save_result(target)
        self.assertEqual(target.read_bytes(), b"existing data")
        self.assertEqual(list(self.folder.glob(".a51_result_*.tmp")), [])

    def test_existing_destination_can_be_replaced(self):
        target = self.folder / "existing.txt"
        target.write_bytes(b"existing data")
        self.controller.select_file(self.source)
        view = self.run_file(ENCRYPT)
        self.controller.save_result(target)
        self.assertEqual(target.read_bytes(), view.file_result.data)

    def test_empty_file(self):
        empty = self.folder / "empty.txt"
        empty.write_bytes(b"")
        self.controller.select_file(empty)
        self.run_file(ENCRYPT)
        target = self.folder / "empty_encrypted.txt"
        self.controller.save_result(target)
        self.assertEqual(target.read_bytes(), b"")

    def test_source_removed_after_selection(self):
        self.controller.select_file(self.source)
        self.source.unlink()
        with self.assertRaises(FileNotFoundError):
            self.run_file(ENCRYPT)
        self.assertIsNone(self.controller.result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
