# -*- coding: utf-8 -*-
"""Test tầng SERVICE (bit / văn bản / ký tự) qua CipherService."""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from service import (  # noqa: E402
    CipherService, FrameValidationError, KeyValidationError, UnknownAlgorithmError,
)

FULL_KEY = "0001000100100010001100110100010001010101011001100111011110001000"
BRICENO_KEY = "0001001000100011010001010110011110001001101010111100110111101111"
TINY_KEY = "10010101001110100110000"


class TestRegistryAndKeys(unittest.TestCase):
    def setUp(self):
        self.service = CipherService()

    def test_algorithms_are_registered(self):
        self.assertEqual(self.service.list_algorithms(), ["a5/1", "a5/1-tiny"])

    def test_info_exposes_frame_usage(self):
        self.assertTrue(self.service.info("a5/1")["uses_frame"])
        self.assertFalse(self.service.info("a5/1-tiny")["uses_frame"])

    def test_tiny_23_bit_key_packing(self):
        self.assertEqual(self.service.key_binary_to_bytes("a5/1-tiny", TINY_KEY),
                         bytes.fromhex("953a60"))

    def test_wrong_key_length_and_chars_are_rejected(self):
        with self.assertRaises(KeyValidationError):
            self.service.key_binary_to_bytes("a5/1-tiny", "0" * 22)
        with self.assertRaises(KeyValidationError):
            self.service.key_binary_to_bytes("a5/1", "0" * 63)
        with self.assertRaises(KeyValidationError):
            self.service.key_binary_to_bytes("a5/1-tiny", "1" * 22 + "x")

    def test_unknown_algorithm_is_rejected(self):
        with self.assertRaises(UnknownAlgorithmError):
            self.service.info("not-an-algorithm")

    def test_generated_keys_have_right_length(self):
        for name, bits in (("a5/1", 64), ("a5/1-tiny", 23)):
            key = self.service.generate_key_binary(name)
            self.assertEqual(len(key), bits)
            self.assertTrue(set(key) <= {"0", "1"})
            self.service.key_binary_to_bytes(name, key)  # không ném lỗi

    def test_frame_validation_and_parsing(self):
        self.assertEqual(self.service.parse_frame(""), 0)
        self.assertEqual(self.service.parse_frame(" 12 "), 12)
        with self.assertRaises(FrameValidationError):
            self.service.parse_frame("abc")
        with self.assertRaises(FrameValidationError):
            self.service.validate_frame("a5/1", 1 << 22)
        with self.assertRaises(FrameValidationError):
            self.service.validate_frame("a5/1", -1)
        with self.assertRaises(FrameValidationError):
            self.service.validate_frame("a5/1-tiny", 1)
        self.assertEqual(self.service.validate_frame("a5/1", (1 << 22) - 1), (1 << 22) - 1)

    def test_clean_binary_accepts_slide_notation(self):
        self.assertEqual(CipherService.clean_binary(" 100101.01001110\n.100110000 "), TINY_KEY)


class TestBinaryMode(unittest.TestCase):
    def setUp(self):
        self.service = CipherService()

    def test_tiny_course_example(self):
        r = self.service.encrypt_binary("a5/1-tiny", "111", TINY_KEY)
        self.assertEqual(r["keystream"], "100")
        self.assertEqual(r["ciphertext_binary"], "011")
        d = self.service.decrypt_binary("a5/1-tiny", "011", TINY_KEY)
        self.assertEqual(d["plaintext_binary"], "111")

    def test_full_known_answer(self):
        r = self.service.encrypt_binary("a5/1", "0" * 112, BRICENO_KEY, frame=0x134)
        expected = bin(int("534EAA582FE8151AB6E1855A728C", 16))[2:].zfill(112)
        self.assertEqual(r["keystream"], expected)
        self.assertEqual(r["ciphertext_binary"], expected)

    def test_roundtrip_any_length(self):
        for name, key in (("a5/1", FULL_KEY), ("a5/1-tiny", TINY_KEY)):
            for bits in ("1", "10110", "1" * 37, "01" * 200):
                enc = self.service.encrypt_binary(name, bits, key)
                dec = self.service.decrypt_binary(name, enc["ciphertext_binary"], key)
                self.assertEqual(dec["plaintext_binary"], bits)

    def test_non_binary_input_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.encrypt_binary("a5/1-tiny", "10a1", TINY_KEY)


class TestTextMode(unittest.TestCase):
    def setUp(self):
        self.service = CipherService()

    def test_output_is_consistent(self):
        text = "Backend A5/1 chuẩn 👋"
        r = self.service.encrypt_text("a5/1", text, FULL_KEY, frame=7)
        self.assertEqual(len(r["keystream"]), len(text.encode("utf-8")) * 8)
        self.assertEqual(r["ciphertext_binary"],
                         self.service.bytes_to_binary(bytes.fromhex(r["ciphertext_hex"])))

    def test_roundtrip_vietnamese(self):
        for name, key in (("a5/1", FULL_KEY), ("a5/1-tiny", TINY_KEY)):
            frame = 9 if name == "a5/1" else 0
            enc = self.service.encrypt_text(name, "Xin chào Việt Nam!\r\n", key, frame)
            dec = self.service.decrypt_text(name, enc["ciphertext_hex"], key, frame)
            self.assertEqual(dec["plaintext"], "Xin chào Việt Nam!\r\n")

    def test_wrong_frame_does_not_restore_text(self):
        enc = self.service.encrypt_text("a5/1", "Hello A5/1", FULL_KEY, frame=1)
        try:
            dec = self.service.decrypt_text("a5/1", enc["ciphertext_hex"], FULL_KEY, frame=2)
        except ValueError:
            return  # không phải UTF-8 hợp lệ cũng là kết quả chấp nhận được
        self.assertNotEqual(dec["plaintext"], "Hello A5/1")

    def test_bad_hex_is_rejected(self):
        with self.assertRaises(ValueError):
            self.service.decrypt_text("a5/1", "xyz", FULL_KEY)

    def test_hex_with_spaces_is_accepted(self):
        enc = self.service.encrypt_text("a5/1", "abc", FULL_KEY)
        spaced = " ".join(enc["ciphertext_hex"][i:i + 2] for i in range(0, len(enc["ciphertext_hex"]), 2))
        self.assertEqual(self.service.decrypt_text("a5/1", spaced, FULL_KEY)["plaintext"], "abc")


class TestTinyChars(unittest.TestCase):
    def setUp(self):
        self.service = CipherService()

    def test_slide_table(self):
        from service import tiny_chars
        self.assertEqual(tiny_chars.chars_to_bits("HEAD"), "111100000011")  # theo bảng A..H (slide ghi nhầm 111100000111)
        self.assertEqual(tiny_chars.chars_to_bits("ABCDEFGH"), "000001010011100101110111")
        self.assertEqual(tiny_chars.bits_to_chars("111100000011"), "HEAD")

    def test_chars_roundtrip(self):
        enc = self.service.encrypt_chars("HEAD", TINY_KEY)
        self.assertEqual(enc["plaintext_binary"], "111100000011")
        self.assertEqual(len(enc["ciphertext_binary"]), 12)
        dec = self.service.decrypt_chars(enc["ciphertext_binary"], TINY_KEY)
        self.assertEqual(dec["plaintext"], "HEAD")

    def test_first_bits_match_course_example(self):
        # H = 111 với khóa trên lớp -> 011 (keystream 100)
        enc = self.service.encrypt_chars("H", TINY_KEY)
        self.assertEqual((enc["keystream"], enc["ciphertext_binary"]), ("100", "011"))

    def test_lowercase_and_spaces_are_normalized(self):
        self.assertEqual(self.service.encrypt_chars("he ad", TINY_KEY)["plaintext"], "HEAD")

    def test_letters_outside_a_to_h_are_rejected(self):
        with self.assertRaises(ValueError):
            self.service.encrypt_chars("HEAL", TINY_KEY)

    def test_bits_not_multiple_of_3_are_rejected(self):
        with self.assertRaises(ValueError):
            self.service.decrypt_chars("0101", TINY_KEY)


if __name__ == "__main__":
    unittest.main(verbosity=2)
