# -*- coding: utf-8 -*-
"""Tầng GIAO DIỆN: chỉ gọi service, không chứa thuật toán mã hóa."""
