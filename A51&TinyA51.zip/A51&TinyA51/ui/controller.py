# -*- coding: utf-8 -*-
"""Bộ điều phối giữa giao diện và service - KHÔNG phụ thuộc Tkinter.

Giao diện (``app.py``) chỉ lo vẽ widget và thu dữ liệu người dùng nhập. Mọi
việc còn lại - chọn dịch vụ theo kiểu nhập, gọi service, định dạng kết quả,
chọn/lưu tệp - nằm ở đây nên có thể test mà không cần màn hình.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from service import (
    CipherService,
    FileCipherService,
    FileCryptoError,
    FileCryptoResult,
)

# Các kiểu đầu vào
MODE_BINARY = "binary"   # nhập chuỗi bit nhị phân
MODE_TEXT = "text"       # nhập văn bản bình thường (UTF-8)
MODE_FILE = "file"       # tải tệp văn bản .txt lên
MODE_CHARS = "chars"     # nhập ký tự (chỉ Tiny A5/1)

# Các chức năng
ENCRYPT = "encrypt"
DECRYPT = "decrypt"


@dataclass(frozen=True)
class OutputView:
    """Kết quả đã định dạng để giao diện hiển thị."""

    text: str                                   # nội dung hiện trong ô kết quả
    copy_text: str                              # nội dung khi bấm "Sao chép"
    file_result: Optional[FileCryptoResult] = None  # chỉ có ở kiểu tệp


def _block(label: str, value: str) -> str:
    return f"{label}:\n{value}\n"


class CipherController:
    """Điều phối một panel (một thuật toán) của giao diện."""

    def __init__(self, cipher: CipherService | None = None,
                 files: FileCipherService | None = None):
        self.cipher = cipher or CipherService()
        self.files = files or FileCipherService(self.cipher)
        self.input_path: Path | None = None
        self.result: FileCryptoResult | None = None

    # ------------------------------------------------------------------
    # Chọn / lưu tệp
    # ------------------------------------------------------------------
    def select_file(self, filename: str | Path) -> Path:
        path = Path(filename).expanduser().resolve()
        if not path.is_file():
            raise FileCryptoError("FILE_NOT_FOUND", "Không tìm thấy tệp đã chọn.")
        if path.suffix.lower() != ".txt":
            raise FileCryptoError("INVALID_FILE_TYPE", "Hãy chọn tệp có phần mở rộng .txt.")
        self.input_path = path
        self.clear_result()
        return path

    def clear_result(self) -> None:
        self.result = None

    def save_result(self, filename: str | Path) -> Path:
        """Lưu kết quả của tệp ra đĩa (ghi tệp tạm rồi thay thế để không hỏng dữ liệu)."""
        if self.result is None:
            raise FileCryptoError("NO_RESULT", "Hãy mã hóa hoặc giải mã tệp trước khi lưu kết quả.")
        destination = Path(filename).expanduser().resolve()
        if destination.suffix.lower() != ".txt":
            raise FileCryptoError("INVALID_FILE_TYPE", "Hãy lưu kết quả thành tệp .txt.")
        if self.input_path is not None:
            same_path = destination == self.input_path.resolve()
            if destination.exists() and self.input_path.exists():
                same_path = same_path or destination.samefile(self.input_path)
            if same_path:
                raise FileCryptoError(
                    "SOURCE_OVERWRITE",
                    "Hãy chọn tên hoặc vị trí khác để giữ nguyên tệp nguồn.",
                )
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb", dir=destination.parent, prefix=".a51_result_",
                suffix=".tmp", delete=False,
            ) as output:
                temporary_path = Path(output.name)
                output.write(self.result.data)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary_path, destination)
        finally:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
        return destination

    # ------------------------------------------------------------------
    # Chạy mã hóa / giải mã
    # ------------------------------------------------------------------
    def run(self, algorithm: str, mode: str, operation: str, key: str,
            frame_text: str, input_text: str, ciphertext_format: str | None = None) -> OutputView:
        """Thực hiện một thao tác và trả về kết quả đã định dạng.

        Ném ``ValueError`` (hoặc lớp con) với thông báo tiếng Việt nếu đầu vào sai.
        """
        self.clear_result()
        if operation not in (ENCRYPT, DECRYPT):
            raise ValueError("Chức năng không hợp lệ.")
        enc = operation == ENCRYPT
        svc = self.cipher
        info = svc.info(algorithm)
        key = svc.clean_binary(key)
        frame = svc.parse_frame(frame_text) if info["uses_frame"] else 0
        header = f"Thuật toán: {algorithm}" + (f" · Số khung: {frame}" if info["uses_frame"] else "") + "\n\n"

        if mode == MODE_FILE:
            if self.input_path is None:
                raise FileCryptoError("MISSING_FILE", "Hãy chọn một tệp .txt trước khi xử lý.")
            with self.input_path.open("rb") as uploaded:
                result = self.files.process_file(
                    uploaded, self.input_path.name, operation, key, algorithm, frame
                )
            self.result = result
            return OutputView(result.content, result.content, result)

        # A5/1 đầy đủ hỗ trợ chọn rõ định dạng bản mã khi giải mã.
        # Hex được xử lý như ciphertext của văn bản UTF-8; Binary là luồng bit.
        if not enc and algorithm == "a5/1" and mode in (MODE_BINARY, MODE_TEXT):
            # Giữ tương thích với các lời gọi cũ: MODE_TEXT khi giải mã vốn là Hex.
            if ciphertext_format is None:
                ciphertext_format = "hex" if mode == MODE_TEXT else "binary"
            if ciphertext_format == "hex":
                r = svc.decrypt_text(algorithm, input_text, key, frame)
                body = (_block("Bản mã (hex)", r["ciphertext_hex"])
                        + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"])
                        + "\n" + _block("Keystream", r["keystream"])
                        + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"])
                        + "\n" + _block("Bản rõ (văn bản)", r["plaintext"]))
                return OutputView(header + body, r["plaintext"])
            if ciphertext_format != "binary":
                raise ValueError("Định dạng bản mã không hợp lệ.")
            mode = MODE_BINARY

        if mode == MODE_BINARY:
            bits = svc.clean_binary(input_text)
            if not bits:
                raise ValueError("Hãy nhập chuỗi bit đầu vào.")
            if enc:
                r = svc.encrypt_binary(algorithm, bits, key, frame)
                body = (_block("Bản rõ (bit)", r["plaintext_binary"])
                        + "\n" + _block("Keystream", r["keystream"])
                        + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"]))
                return OutputView(header + body, r["ciphertext_binary"])
            r = svc.decrypt_binary(algorithm, bits, key, frame)
            # Với bản rõ nhị phân, thử diễn giải các byte sau giải mã thành UTF-8
            # để người dùng có thể đọc được nội dung văn bản bên cạnh chuỗi bit.
            try:
                plaintext_bytes = svc.binary_to_bytes(r["plaintext_binary"])
                try:
                    plaintext_text = plaintext_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    plaintext_text = (
                        "Không thể hiển thị thành văn bản UTF-8 hợp lệ "
                        "(có thể đây là dữ liệu nhị phân hoặc sai khóa/số khung)."
                    )
            except ValueError:
                plaintext_text = (
                    "Không thể chuyển thành văn bản: độ dài bản rõ không chia hết cho 8 bit. "
                    "Bản rõ nhị phân vẫn được giữ nguyên ở phía trên."
                )
            body = (_block("Bản mã (bit)", r["ciphertext_binary"])
                    + "\n" + _block("Keystream", r["keystream"])
                    + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"])
                    + "\n" + _block("Bản rõ (văn bản UTF-8)", plaintext_text))
            return OutputView(header + body, r["plaintext_binary"])

        if mode == MODE_TEXT:
            if not input_text.strip():
                raise ValueError("Hãy nhập nội dung đầu vào.")
            if enc:
                r = svc.encrypt_text(algorithm, input_text, key, frame)
                body = (_block("Bản mã (hex)", r["ciphertext_hex"])
                        + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"])
                        + "\n" + _block("Keystream", r["keystream"])
                        + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"]))
                return OutputView(header + body, r["ciphertext_hex"])
            r = svc.decrypt_text(algorithm, input_text, key, frame)
            body = (_block("Bản rõ (văn bản)", r["plaintext"])
                    + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"])
                    + "\n" + _block("Keystream", r["keystream"])
                    + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"]))
            return OutputView(header + body, r["plaintext"])

        if mode == MODE_CHARS:
            if enc:
                if not input_text:
                    raise ValueError("Hãy nhập ký tự đầu vào.")
                r = svc.encrypt_chars(input_text, key)
                body = (_block("Bản rõ (ký tự)", r["plaintext"])
                        + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"])
                        + "\n" + _block("Keystream", r["keystream"])
                        + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"]))
                return OutputView(header + body, r["ciphertext_binary"])
            bits = svc.clean_binary(input_text)
            if not bits:
                raise ValueError("Hãy nhập bản mã dạng chuỗi bit.")
            r = svc.decrypt_chars(bits, key)
            body = (_block("Bản rõ (ký tự)", r["plaintext"])
                    + "\n" + _block("Bản rõ (bit)", r["plaintext_binary"])
                    + "\n" + _block("Keystream", r["keystream"])
                    + "\n" + _block("Bản mã (bit)", r["ciphertext_binary"]))
            return OutputView(header + body, r["plaintext"])

        raise ValueError("Kiểu đầu vào không hợp lệ.")
