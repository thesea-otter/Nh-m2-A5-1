# -*- coding: utf-8 -*-
"""Tầng TẤN CÔNG: minh họa cách khai thác điểm yếu của hệ mã

Ap dụng cho Tiny A5/1: khóa 23 bit đủ nhỏ để vét cạn (2**23 ≈ 8,4 triệu khóa) trong vài
giây đến vài chục giây trên máy cá nhân"""

from .tiny_known_plaintext import (
    SO_O_BAN_DO,
    TONG_SO_KHOA,
    dem_khoa_tuong_duong,
    khoa_tuong_duong,
    sinh_keystream,
    trang_thai_sau,
    vet_can_khoa,
)

__all__ = [
    "SO_O_BAN_DO",
    "TONG_SO_KHOA",
    "dem_khoa_tuong_duong",
    "khoa_tuong_duong",
    "sinh_keystream",
    "trang_thai_sau",
    "vet_can_khoa",
]
