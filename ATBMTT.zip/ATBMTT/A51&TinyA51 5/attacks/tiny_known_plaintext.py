# -*- coding: utf-8 -*-
"""Tấn công biết-bản-rõ (known-plaintext) lên Tiny A5/1 bằng cách vét cạn không gian khóa."""

from __future__ import annotations

from multiprocessing import Pool, cpu_count
from typing import Callable, List, Optional, Sequence, Tuple

TONG_SO_KHOA = 1 << 23   # Tiny A5/1 dùng khóa 23 bit -> 8.388.608 khóa có thể có
SO_O_BAN_DO = 64         # chia không gian khóa thành 64 phần để báo tiến độ lên giao diện


def sinh_khoa_dong(k: int, n: int, muc_tieu: Optional[Sequence[int]] = None) -> Optional[List[int]]:
    """Sinh n bit keystream của khóa K (số nguyên 23 bit, X‖Y‖Z = 6‖8‖9 bit).

    Nếu truyền ``muc_tieu`` (một đoạn keystream đã biết), hàm dừng ngay và trả về ``None``
    khi gặp bit không khớp, thay vì sinh hết n bit rồi mới so sánh. Giúp việc vét
    cạn nhanh hơn.
    """
    x, y, z = k >> 17, (k >> 9) & 0xFF, k & 0x1FF
    out = []
    for i in range(n):
        bx, by, bz = (x >> 4) & 1, (y >> 4) & 1, (z >> 5) & 1       # bit điều khiển x1, y3, z3
        m = 1 if bx + by + bz >= 2 else 0
        tx = ((x >> 3) ^ (x >> 1) ^ x) & 1                          # phản hồi X: x2 ^ x4 ^ x5
        ty = ((y >> 1) ^ y) & 1                                     # phản hồi Y: y6 ^ y7
        tz = ((z >> 6) ^ (z >> 1) ^ z) & 1                          # phản hồi Z: z2 ^ z7 ^ z8
        if bx == m:
            x = (x >> 1) | (tx << 5)
        if by == m:
            y = (y >> 1) | (ty << 7)
        if bz == m:
            z = (z >> 1) | (tz << 8)
        bit = (x ^ y ^ z) & 1                                       # bit ngõ ra: x5 ^ y7 ^ z8
        if muc_tieu is not None and bit != muc_tieu[i]:
            return None
        out.append(bit)
    return out


def sinh_keystream(k: int, n: int) -> List[int]:
    """Sinh n bit keystream của khóa K, dùng khi đã biết chắc khóa (không cần dừng sớm)."""
    return sinh_khoa_dong(k, n)


def _quet_mot_phan(tham_so: Tuple[int, int, Sequence[int]]) -> List[int]:
    """Quét các khóa trong [lo, hi), trả về danh sách khóa khớp đoạn keystream đã biết.

    Hàm này chạy trong tiến trình con (``multiprocessing.Pool``) nên phải là hàm ở cấp module
    để có thể "pickle" được.
    """
    lo, hi, s_biet = tham_so
    return [k for k in range(lo, hi) if sinh_khoa_dong(k, len(s_biet), s_biet) is not None]


def vet_can_khoa(
    s_biet: Sequence[int],
    on_progress: Optional[Callable[[int, int, int], None]] = None,
    so_tien_trinh: Optional[int] = None,
) -> List[int]:
    """Vét cạn toàn bộ 2**23 khóa, trả về danh sách khóa (số nguyên) khớp đoạn keystream s_biet.

    on_progress(so_khoa_da_xet, chi_so_phan, so_ung_vien_trong_phan) được gọi sau mỗi 1/64
    không gian khóa đã quét xong, để giao diện cập nhật tiến độ.
    """
    buoc = TONG_SO_KHOA // SO_O_BAN_DO
    cac_phan = [(i * buoc, (i + 1) * buoc, s_biet) for i in range(SO_O_BAN_DO)]
    ket_qua, da_xet = [], 0
    with Pool(so_tien_trinh or cpu_count()) as pool:
        for idx, danh_sach in enumerate(pool.imap(_quet_mot_phan, cac_phan)):
            ket_qua.extend(danh_sach)
            da_xet += buoc
            if on_progress:
                on_progress(da_xet, idx, len(danh_sach))
    return sorted(ket_qua)


# ----------------------------------------------------------------------------------------
# Khóa tương đương (hợp nhất trạng thái)
# ----------------------------------------------------------------------------------------
# Luật clock theo đa số là hàm NHIỀU-VỀ-MỘT: nhiều trạng thái (X, Y, Z) khác nhau có thể
# cùng dẫn tới một trạng thái duy nhất sau một bước dịch (mỗi khóa đứng yên một thanh ghi
# khác nhau, các thanh ghi còn lại quay vào cùng một giá trị). Từ lúc hai khóa hợp nhất,
# keystream của chúng giống hệt nhau, nên bản mã giải ra cùng một bản rõ. Hai hàm dưới đây
# giúp quan sát hiện tượng đó; chúng KHÔNG dùng trong vòng vét cạn nên không làm chậm nó.

def trang_thai_sau(k: int, so_buoc: int) -> Tuple[int, int, int]:
    """Trạng thái (X, Y, Z) dưới dạng số nguyên của khóa K sau ``so_buoc`` lần clock.

    Cài đặt giống ``sinh_khoa_dong`` nhưng trả về trạng thái thay vì bit sinh ra; dùng để
    chứng minh hai khóa hợp nhất (cùng trạng thái) ở bước nào.
    """
    x, y, z = k >> 17, (k >> 9) & 0xFF, k & 0x1FF
    for _ in range(so_buoc):
        bx, by, bz = (x >> 4) & 1, (y >> 4) & 1, (z >> 5) & 1
        m = 1 if bx + by + bz >= 2 else 0
        tx = ((x >> 3) ^ (x >> 1) ^ x) & 1
        ty = ((y >> 1) ^ y) & 1
        tz = ((z >> 6) ^ (z >> 1) ^ z) & 1
        if bx == m:
            x = (x >> 1) | (tx << 5)
        if by == m:
            y = (y >> 1) | (ty << 7)
        if bz == m:
            z = (z >> 1) | (tz << 8)
    return x, y, z


def khoa_tuong_duong(
    k: int,
    n: int,
    on_progress: Optional[Callable[[int, int, int], None]] = None,
    so_tien_trinh: Optional[int] = None,
) -> List[int]:
    """Mọi khóa 23 bit (kể cả chính K) sinh ra cùng n bit keystream đầu tiên với K.

    Thực hiện bằng một lần vét cạn toàn bộ 2**23 khóa (vài giây), nên nên gọi một lần rồi
    dùng lại kết quả.
    """
    if not isinstance(n, int) or isinstance(n, bool) or n < 1:
        raise ValueError("n phải là số nguyên dương")
    if not 0 <= k < TONG_SO_KHOA:
        raise ValueError("Khóa phải là số nguyên 23 bit")
    return vet_can_khoa(sinh_keystream(k, n), on_progress, so_tien_trinh)


def dem_khoa_tuong_duong(k: int, n: int, so_tien_trinh: Optional[int] = None) -> int:
    """Số khóa (kể cả chính K) có cùng n bit keystream đầu với K; luôn >= 1."""
    return len(khoa_tuong_duong(k, n, so_tien_trinh=so_tien_trinh))
