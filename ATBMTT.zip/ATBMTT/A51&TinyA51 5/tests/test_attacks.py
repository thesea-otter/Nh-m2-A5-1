# -*- coding: utf-8 -*-
"""Test tầng TẤN CÔNG: khớp với A5_1_Tiny và tìm đúng khóa thật trên một phần nhỏ không gian khóa."""

import os
import random
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from algorithms.a5_1_tiny import A5_1_Tiny  # noqa: E402
from attacks.tiny_known_plaintext import (  # noqa: E402
    _quet_mot_phan,
    dem_khoa_tuong_duong,
    khoa_tuong_duong,
    sinh_keystream,
    trang_thai_sau,
)


class TestSinhKeystreamKhopVoiA5_1_Tiny(unittest.TestCase):
    def test_matches_a5_1_tiny_on_random_keys(self):
        tiny = A5_1_Tiny()
        rng = random.Random(0)
        for _ in range(500):
            k = rng.getrandbits(23)
            n = rng.randint(1, 40)
            key_bytes = (k << 1).to_bytes(3, "big")
            self.assertEqual(sinh_keystream(k, n), tiny.generate_keystream(key_bytes, 0, n))

    def test_course_known_example(self):
        # K = 10010101001110100110000, P = 111 -> keystream 100 (ví dụ trên lớp).
        k = int("10010101001110100110000", 2)
        self.assertEqual(sinh_keystream(k, 3), [1, 0, 0])


class TestQuetMotPhan(unittest.TestCase):
    def test_finds_real_key_in_its_own_range(self):
        k_that = int("10010101001110100110000", 2)
        s_biet = sinh_keystream(k_that, 16)
        lo = (k_that // 1000) * 1000
        hi = lo + 1000
        ung_vien = _quet_mot_phan((lo, hi, s_biet))
        self.assertIn(k_that, ung_vien)

    def test_wrong_keystream_finds_nothing_in_a_small_range(self):
        s_biet = [1, 1, 1, 1, 1, 1, 1, 1]
        ung_vien = _quet_mot_phan((0, 2000, s_biet))
        self.assertIsInstance(ung_vien, list)  # chỉ cần chạy không lỗi; danh sách có thể rỗng

# Bốn khóa quan sát được trong demo: khác nhau nhưng cho cùng keystream (hợp nhất trạng thái).
NHOM_TUONG_DUONG = [
    "00101111011100110100110",
    "01011101101110110100110",  # khóa thật trong lần demo
    "01011111011100110100110",
    "01011111011100111010011",
]


class TestKhoaTuongDuong(unittest.TestCase):
    def test_equivalent_keys_have_identical_keystream(self):
        tiny = A5_1_Tiny()
        khoa = [int(s, 2) for s in NHOM_TUONG_DUONG]
        self.assertEqual(len(set(khoa)), 4)  # thật sự là 4 khóa khác nhau
        ks = [sinh_keystream(k, 400) for k in khoa]
        self.assertTrue(all(x == ks[0] for x in ks))
        # Đối chiếu độc lập với lớp A5_1_Tiny.
        for k in khoa:
            self.assertEqual(tiny.generate_keystream((k << 1).to_bytes(3, "big"), 0, 400), ks[0])

    def test_equivalent_keys_merge_after_first_clock(self):
        trang_thai = {trang_thai_sau(int(s, 2), 1) for s in NHOM_TUONG_DUONG}
        self.assertEqual(len(trang_thai), 1)

    def test_trang_thai_sau_matches_a5_1_tiny_clocking(self):
        tiny = A5_1_Tiny()
        rng = random.Random(1)
        for _ in range(200):
            k = rng.getrandbits(23)
            x, y, z = tiny._key_setup((k << 1).to_bytes(3, "big"))
            for _ in range(5):
                x, y, z = tiny._clock_majority(x, y, z)
            va = lambda bits: int("".join(map(str, bits)), 2)  # noqa: E731
            self.assertEqual(trang_thai_sau(k, 5), (va(x), va(y), va(z)))

    def test_all_three_registers_can_clock_together(self):
        # Khóa 3 bit điều khiển cùng bằng 1 (x1=y3=z3=1): cả 3 thanh ghi đều quay.
        k = int("01011111011100110100110", 2)
        x, y, z = k >> 17, (k >> 9) & 0xFF, k & 0x1FF
        self.assertEqual(((x >> 4) & 1, (y >> 4) & 1, (z >> 5) & 1), (1, 1, 1))
        x1, y1, z1 = trang_thai_sau(k, 1)
        self.assertNotEqual((x1, y1, z1), (x, y, z))
        self.assertEqual(x1 >> 5, ((x >> 3) ^ (x >> 1) ^ x) & 1)  # X thật sự đã quay

    def test_count_equivalent_keys_full_scan(self):
        # Một lần vét cạn toàn bộ 2**23 khóa (vài giây).
        k = int(NHOM_TUONG_DUONG[1], 2)
        nhom = khoa_tuong_duong(k, 84)
        self.assertEqual(sorted(nhom), sorted(int(s, 2) for s in NHOM_TUONG_DUONG))
        self.assertEqual(dem_khoa_tuong_duong(k, 84), 4)

    def test_count_rejects_bad_input(self):
        with self.assertRaises(ValueError):
            dem_khoa_tuong_duong(1, 0)
        with self.assertRaises(ValueError):
            dem_khoa_tuong_duong(1 << 23, 10)


if __name__ == "__main__":
    unittest.main()
