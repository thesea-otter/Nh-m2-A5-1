# -*- coding: utf-8 -*-
"""Test tầng SERVICE của demo tấn công.

Lưu ý: test_finds_unique_real_key chạy vét cạn thật trên toàn bộ 2**23 khóa nên mất vài giây
đến vài chục giây tùy máy, lâu hơn hẳn các test còn lại của dự án.
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from service.attack_service import AttackInputError, AttackService, KHOA_DEMO_MAC_DINH  # noqa: E402


class TestAttackService(unittest.TestCase):
    def setUp(self):
        self.svc = AttackService()

    def test_finds_unique_real_key(self):
        result = self.svc.run(
            "10010101001110100110000", "GSM: gui tien 100 USD", 40, " USD"
        )
        self.assertTrue(result.real_key_in_candidates)
        self.assertEqual(result.candidates_found, 1)
        self.assertTrue(any(c.is_real_key for c in result.candidates))
        self.assertTrue(result.same_keystream)  # một ứng viên duy nhất: tầm thường là đúng

    def test_equivalent_keys_are_reported_as_same_keystream(self):
        # Khóa thật của lần demo có 3 khóa "anh em" cùng keystream trong không gian 2**23.
        result = self.svc.run(
            "01011101101110110100110",
            "MA OTP CUA BAN LA 739215. KHONG CHIA SE MA NAY",
            84,
            "KHONG CHIA SE MA NAY",
        )
        self.assertTrue(result.real_key_in_candidates)
        self.assertEqual(result.candidates_found, 4)
        self.assertTrue(result.same_keystream)
        self.assertEqual(len({c.plaintext for c in result.candidates}), 1)

    def test_default_demo_key_gives_single_candidate(self):
        for bits in (64, 84):
            result = self.svc.run(
                KHOA_DEMO_MAC_DINH,
                "MA OTP CUA BAN LA 739215. KHONG CHIA SE MA NAY",
                bits,
                "KHONG CHIA SE MA NAY",
            )
            self.assertEqual(result.candidates_found, 1)
            self.assertTrue(result.candidates[0].is_real_key)

    def test_invalid_key_length_is_rejected(self):
        with self.assertRaises(AttackInputError):
            self.svc.run("101", "abc", 8)

    def test_invalid_key_characters_are_rejected(self):
        with self.assertRaises(AttackInputError):
            self.svc.run("1001010100111010011000x", "abc", 8)

    def test_empty_message_is_rejected(self):
        with self.assertRaises(AttackInputError):
            self.svc.run("10010101001110100110000", "", 8)

    def test_known_bits_out_of_range_is_rejected(self):
        with self.assertRaises(AttackInputError):
            self.svc.run("10010101001110100110000", "abc", 999)
        with self.assertRaises(AttackInputError):
            self.svc.run("10010101001110100110000", "abc", 0)


if __name__ == "__main__":
    unittest.main()
