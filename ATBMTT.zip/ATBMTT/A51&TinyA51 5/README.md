# A5/1 & Tiny A5/1 (Nhóm 2)

Chương trình của nhóm là Ứng dụng desktop (Python + Tkinter) mã hóa và giải mã bằng A5/1 đầy đủ và Tiny A5/1, kèm cửa sổ mô phỏng từng bước và demo tấn công biết bản rõ lên Tiny A5/1. Thuật toán do nhóm tự cài đặt, chạy offline trực tiếp trên Python.

# Tính năng
A5/1 đầy đủ:
- Mã hóa/giải mã chuỗi bit
- Mã hóa/giải mã văn bản UTF-8 (có tiếng Việt)
- Mã hóa/giải mã tệp .txt (tối đa 64 KiB)

Tiny A5/1:
- Mã hóa/giải mã chuỗi bit:
- Mã hóa chữ cái A–H (mỗi chữ 3 bit)
- Mô phỏng từng bước các thanh ghi:
- Demo tấn công

# Cài đặt và chạy

Yêu cầu: Python 3.9 trở lên có Tcl/Tk
   - Windows: nhấp đúp `start_windows.bat`
   - Mọi hệ điều hành: `python run_app.py` (macOS/Linux có thể cần gõ `python3`)
Cửa sổ mở ra có 3 tab: A5/1 đầy đủ, Tiny A5/1 và Demo tấn công.

# Thao tác chung ở tab mã hóa

1. Cột trái: chọn Mã hóa hoặc Giải mã, rồi chọn Kiểu đầu vào.
2. Cột phải: nhập khóa (bấm Tạo khóa để sinh ngẫu nhiên), nhập dữ liệu, bấm nút thực hiện.
3. Kết quả hiện bản rõ, keystream và bản mã. Dùng các nút Sao chép để chép từng dạng kết quả (hex, nhị phân, ký tự).

Khóa gõ liền (`10010101001110100110000`) hoặc có dấu chấm (`100101.01001110.100110000`) đều được; chương trình tự bỏ dấu chấm và khoảng trắng. Khi giải mã phải dùng đúng khóa (và số khung với A5/1) đã dùng lúc mã hóa.

# Tab A5/1 đầy đủ
Khóa 64 bit. Số khung từ 0 đến 4.194.303 (để trống là 0).

Chuỗi bit:
1. Kiểu đầu vào: Chuỗi bit nhị phân. Nhập khóa, số khung, chuỗi bit, bấm Mã hóa.
2. Giải mã: chọn Giải mã, Định dạng bản mã là Nhị phân, nhập bản mã.

Văn bản:
1. Kiểu đầu vào: Văn bản. Nhập nội dung, bấm Mã hóa. Bản mã hiện dạng hex và bit.
2. Giải mã: chọn Giải mã, Định dạng bản mã là Thập lục phân hoặc Nhị phân, bấm Giải mã.

Tệp .txt:
1. Kiểu đầu vào: Tải tệp .txt, bấm Chọn tệp (thử với `examples/tieng_viet.txt`).
2. Bấm Mã hóa tệp. Bản mã được lưu dạng Base64.
3. Bấm Lưu kết quả thành .txt để ghi tệp (tên gợi ý `<tên>_encrypted.txt`).
4. Giải mã: chọn Giải mã, chọn tệp `_encrypted.txt`, bấm Giải mã tệp, rồi lưu kết quả.

Chỉ nhận tệp .txt mã hóa UTF-8, tối đa 64 KiB, và không cho lưu đè lên tệp nguồn.

# Tab Tiny A5/1

Khóa 23 bit gồm X (6 bit), Y (8 bit), Z (9 bit). Không dùng số khung.

Chuỗi bit: dùng như tab A5/1. Ví dụ trên lớp: khóa `100101.01001110.100110000`, bản rõ `111`, bản mã `011`.

Ký tự A–H:
1. Kiểu đầu vào: Ký tự. Nhập chữ từ A đến H (khoảng trắng bị bỏ).
2. Bảng đổi: `A=000 B=001 C=010 D=011 E=100 F=101 G=110 H=111`.
3. Bấm Mã hóa. Bản mã hiện dạng bit và dạng chữ cái (khi số bit chia hết cho 3).
4. Giải mã: nhập bản mã dạng bit, số bit phải chia hết cho 3.

Mô phỏng từng bước: tick vào ô "Hiển thị trực quan hóa quá trình mã hóa / giải mã" trước khi bấm Mã hóa hoặc Giải mã. Cửa sổ mới hiện từng bước: bit đa số maj(x1, y3, z3) và thanh ghi nào quay, bit phản hồi, bit keystream và kết quả XOR. Có thể bấm tới, lui hoặc cho chạy tự động và chỉnh được tốc độ.

# Tab Demo tấn công

Mô phỏng kẻ tấn công không biết khóa K nhưng biết một đoạn bản rõ, thử toàn bộ 2²³ = 8.388.608 khóa.

1. Nhập Khóa bí mật K (23 bit), chỉ dùng để tạo bản mã minh họa.
2. Nhập Thông điệp bản rõ minh họa (1–100 ký tự).
3. Chọn Số bit đầu của bản rõ mà kẻ tấn công đã biết. Biết càng nhiều bit thì càng ít khóa ứng viên.
4. Nếu muốn, nhập Đoạn cuối đã biết để lọc lại các ứng viên.
5. Bấm Bắt đầu tấn công. Khung Diễn biến hiện tiến độ và danh sách khóa tìm được (thường mất vài giây).

Đôi khi tìm ra nhiều hơn một khóa. Đó là do luật quay theo đa số làm nhiều khóa khác nhau dồn về cùng một trạng thái và cho cùng keystream; đây là đặc tính của thuật toán, không phải lỗi. Khóa thật luôn nằm trong danh sách ứng viên.

# Cấu trúc mã nguồn:
run_app.py, start_windows.bat   khởi chạy ứng dụng
algorithms/                     lõi mật mã
  base_cipher.py                lớp cơ sở: sinh keystream rồi XOR
  a5_1.py                       A5/1 đầy đủ
  a5_1_tiny.py                  Tiny A5/1
attacks/
  tiny_known_plaintext.py       vét cạn 2^23 khóa, chạy song song
service/                        xử lý, không phụ thuộc giao diện
  cipher_service.py             kiểm tra khóa/số khung, mã hóa bit/văn bản/ký tự
  file_service.py               mã hóa/giải mã tệp .txt (Base64)
  tiny_chars.py                 bảng A–H <-> 3 bit
  attack_service.py             điều phối demo tấn công
ui/                             giao diện Tkinter
  app.py, controller.py         cửa sổ chính và điều phối
  tiny_visualizer.py            cửa sổ mô phỏng Tiny A5/1
  attack_panel.py, attack_controller.py   tab Demo tấn công
tests/                          kiểm thử tự động
examples/tieng_viet.txt         tệp văn bản mẫu