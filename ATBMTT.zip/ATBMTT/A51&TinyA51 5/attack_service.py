# -*- coding: utf-8 -*-
"""Tầng SERVICE cho demo tấn công known-plaintext lên Tiny A5/1.

Nhận dữ liệu demo (khóa dùng để tạo bản mã minh họa, thông điệp, số bit bản rõ coi như đã
biết trước), kiểm tra tính hợp lệ, gọi tầng ``attacks`` để vét cạn khóa, rồi trả về kết quả
có cấu trúc cho tầng giao diện. Không phụ thuộc Tkinter nên có thể gọi trực tiếp từ test.

Chỉ áp dụng cho Tiny A5/1 (khóa 23 bit); A5/1 đầy đủ (khóa 64 bit) không vét cạn được nên
không có trong module này.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from attacks.tiny_known_plaintext import SO_O_BAN_DO, TONG_SO_KHOA, sinh_keystream, vet_can_khoa

from .cipher_service import CipherService

KEY_BITS = 23
GIOI_HAN_HIEN_THI = 20       # chỉ hiển thị tối đa 20 khóa ứng viên lên giao diện
GIOI_HAN_KIEM_TRA = 20_000   # quá nhiều ứng viên thì bỏ qua bước lọc bằng đoạn cuối đã biết


class AttackInputError(ValueError):
    """Dữ liệu demo tấn công không hợp lệ."""


@dataclass(frozen=True)
class AttackCandidate:
    key_binary: str
    plaintext: str
    is_real_key: bool


@dataclass(frozen=True)
class AttackResult:
    known_plaintext_binary: str
    ciphertext_binary: str
    known_keystream_binary: str
    tested: int
    total: int
    elapsed_seconds: float
    candidates_found: int
    candidates: List[AttackCandidate]
    verified: bool
    skipped_verification: bool
    real_key_in_candidates: bool
    tile_counts: List[Optional[int]] = field(default_factory=list)


class AttackService:
    """Chạy demo known-plaintext trên Tiny A5/1 bằng cách vét cạn 2**23 khóa."""

    def __init__(self, cipher: Optional[CipherService] = None):
        self.cipher = cipher or CipherService()

    # ------------------------------------------------------------------
    @staticmethod
    def _validate_key(key_binary: str) -> int:
        value = "".join(key_binary.split()).replace(".", "")
        if len(value) != KEY_BITS or any(c not in "01" for c in value):
            raise AttackInputError(
                f"Khóa demo phải gồm đúng {KEY_BITS} bit nhị phân (0/1)."
            )
        return int(value, 2)

    @staticmethod
    def _validate_message(message: str) -> bytes:
        if not message or len(message) > 100:
            raise AttackInputError("Thông điệp minh họa phải có từ 1 đến 100 ký tự.")
        return message.encode("utf-8")

    # ------------------------------------------------------------------
    def run(
        self,
        real_key_binary: str,
        message: str,
        known_bits: int,
        known_suffix: str = "",
        on_progress: Optional[Callable[[int, int, float], None]] = None,
    ) -> AttackResult:
        """Chạy toàn bộ kịch bản tấn công (đồng bộ - nên gọi trong luồng nền của giao diện).

        real_key_binary: khóa 23 bit đóng vai trò "khóa bí mật" dùng để tạo bản mã minh họa;
            trong đời thực đây là khóa mà kẻ tấn công KHÔNG biết.
        message: bản rõ minh họa.
        known_bits: số bit đầu của bản rõ mà kẻ tấn công được giả định đã biết trước.
        known_suffix: đoạn cuối bản rõ dùng để lọc lại ứng viên sau khi vét cạn (tùy chọn).
        on_progress(so_khoa_da_xet, tong_so_khoa, so_giay_da_troi_qua): callback báo tiến độ,
            được gọi nhiều lần trong lúc vét cạn.
        """
        khoa_that = self._validate_key(real_key_binary)
        plaintext_bytes = self._validate_message(message)
        gioi_han_bit = min(64, len(plaintext_bytes) * 8)
        if not isinstance(known_bits, int) or not 1 <= known_bits <= gioi_han_bit:
            raise AttackInputError(
                f"Số bit đã biết trước phải là số nguyên từ 1 đến {gioi_han_bit}."
            )

        plaintext_bits = [int(c) for c in self.cipher.bytes_to_binary(plaintext_bytes)]
        keystream_day_du = sinh_keystream(khoa_that, len(plaintext_bits))
        ciphertext_bits = [p ^ s for p, s in zip(plaintext_bits, keystream_day_du)]
        known_keystream = [
            p ^ c for p, c in zip(plaintext_bits[:known_bits], ciphertext_bits[:known_bits])
        ]

        tile_counts: List[Optional[int]] = [None] * SO_O_BAN_DO
        t0 = time.time()

        def _tien_do(da_xet: int, idx: int, so_ung_vien_phan: int) -> None:
            tile_counts[idx] = so_ung_vien_phan
            if on_progress:
                on_progress(da_xet, TONG_SO_KHOA, time.time() - t0)

        ung_vien = vet_can_khoa(known_keystream, _tien_do)
        elapsed = time.time() - t0

        verified, skipped, hop_le = self._loc_bang_doan_cuoi(
            ung_vien, ciphertext_bits, plaintext_bits, known_bits, known_suffix, message
        )

        candidates = [] if skipped else [
            AttackCandidate(
                format(k, f"0{KEY_BITS}b"),
                self._giai_ma_hien_thi(k, ciphertext_bits),
                k == khoa_that,
            )
            for k in hop_le[:GIOI_HAN_HIEN_THI]
        ]

        return AttackResult(
            known_plaintext_binary="".join(map(str, plaintext_bits[:known_bits])),
            ciphertext_binary="".join(map(str, ciphertext_bits)),
            known_keystream_binary="".join(map(str, known_keystream)),
            tested=TONG_SO_KHOA,
            total=TONG_SO_KHOA,
            elapsed_seconds=elapsed,
            candidates_found=len(hop_le),
            candidates=candidates,
            verified=verified,
            skipped_verification=skipped,
            real_key_in_candidates=khoa_that in ung_vien,
            tile_counts=tile_counts,
        )

    # ------------------------------------------------------------------
    def _loc_bang_doan_cuoi(self, ung_vien, ciphertext_bits, plaintext_bits,
                            known_bits, known_suffix, message):
        """Nếu có đoạn cuối đã biết và danh sách ứng viên không quá dài, lọc lại bằng đoạn đó."""
        skipped = len(ung_vien) > GIOI_HAN_KIEM_TRA
        if skipped or not known_suffix:
            return False, skipped, ung_vien

        suffix_bytes = known_suffix.encode("utf-8")
        if not message.encode("utf-8").endswith(suffix_bytes):
            return False, skipped, ung_vien

        suffix_bits = [int(c) for c in self.cipher.bytes_to_binary(suffix_bytes)]
        vi_tri = len(plaintext_bits) - len(suffix_bits)
        if vi_tri < known_bits:
            return False, skipped, ung_vien

        hop_le = [
            k for k in ung_vien
            if [c ^ s for c, s in zip(ciphertext_bits[vi_tri:],
                                       sinh_keystream(k, len(ciphertext_bits))[vi_tri:])]
            == suffix_bits
        ]
        return True, skipped, hop_le

    @staticmethod
    def _giai_ma_hien_thi(k: int, ciphertext_bits) -> str:
        ks = sinh_keystream(k, len(ciphertext_bits))
        bits = "".join(str(c ^ s) for c, s in zip(ciphertext_bits, ks))
        raw = int(bits, 2).to_bytes(len(bits) // 8, "big") if len(bits) % 8 == 0 else b""
        if not raw:
            return "(độ dài không chia hết cho 8 bit)"
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return "(không phải UTF-8 hợp lệ)"
