# -*- coding: utf-8 -*-
"""Tầng SERVICE: cổng vào duy nhất của ứng dụng tới các thuật toán A5/1.

Module này dùng để:
- đăng ký thuật toán (``a5/1`` và ``a5/1-tiny``);
- kiểm tra khóa / số khung / chuỗi bit đầu vào;
- mã hóa và giải mã theo 3 kiểu đầu vào: chuỗi bit, văn bản, ký tự (Tiny).

Việc xử lý TỆP nằm ở ``file_service.py`` (xây trên module này).
"""

import secrets
from typing import Dict, List

from algorithms.a5_1 import A5_1
from algorithms.a5_1_tiny import A5_1_Tiny
from algorithms.base_cipher import StreamCipherAlgorithm

from . import tiny_chars

# Tên thuật toán dùng xuyên suốt chương trình.
ALGO_A51 = "a5/1"
ALGO_TINY = "a5/1-tiny"


class UnknownAlgorithmError(KeyError):
    """Tên thuật toán chưa được đăng ký."""


class KeyValidationError(ValueError):
    """Khóa nhị phân người dùng nhập không hợp lệ."""


class FrameValidationError(ValueError):
    """Số khung không hợp lệ."""


class CipherService:
    """Điểm vào duy nhất cho việc mã hóa/giải mã mọi biến thể A5."""

    def __init__(self) -> None:
        self._algorithms: Dict[str, StreamCipherAlgorithm] = {}
        self.register(A5_1())
        self.register(A5_1_Tiny())

    # ------------------------------------------------------------------
    # Danh sách thuật toán
    # ------------------------------------------------------------------
    def register(self, algorithm: StreamCipherAlgorithm) -> None:
        if not isinstance(algorithm, StreamCipherAlgorithm):
            raise TypeError("algorithm phải kế thừa StreamCipherAlgorithm")
        self._algorithms[algorithm.name] = algorithm

    def list_algorithms(self) -> List[str]:
        return sorted(self._algorithms)

    def _get(self, algorithm_name: str) -> StreamCipherAlgorithm:
        try:
            return self._algorithms[algorithm_name]
        except KeyError as exc:
            raise UnknownAlgorithmError(
                f"Thuật toán '{algorithm_name}' không tồn tại. "
                f"Các thuật toán có sẵn: {self.list_algorithms()}"
            ) from exc

    def info(self, algorithm_name: str) -> dict:
        algo = self._get(algorithm_name)
        return {
            "name": algo.name,
            "key_bits": algo.key_bits,
            "frame_bits": algo.frame_bits,
            "uses_frame": algo.frame_bits > 0,
        }

    # ------------------------------------------------------------------
    # API mức thấp (bytes)
    # ------------------------------------------------------------------
    def encrypt(
        self, algorithm_name: str, plaintext: bytes, key: bytes, frame: int = 0
    ) -> bytes:
        """Mã hóa bytes. Giải mã dùng lại chính hàm này (mã dòng)."""
        return self._get(algorithm_name).encrypt(plaintext, key, frame)

    def keystream_hex(
        self, algorithm_name: str, key: bytes, frame: int, num_bits: int
    ) -> str:
        return self._get(algorithm_name).keystream_bytes(key, frame, num_bits).hex()

    # ------------------------------------------------------------------
    # Hàm tiện ích chuyển đổi dữ liệu
    # ------------------------------------------------------------------
    @staticmethod
    def text_to_utf8_bytes(plaintext: str) -> bytes:
        if not isinstance(plaintext, str):
            raise TypeError("plaintext phải là chuỗi")
        return plaintext.encode("utf-8")

    @staticmethod
    def bytes_to_binary(data: bytes) -> str:
        return "".join(format(byte, "08b") for byte in data)

    @classmethod
    def text_to_binary(cls, plaintext: str) -> str:
        return cls.bytes_to_binary(cls.text_to_utf8_bytes(plaintext))

    @staticmethod
    def clean_binary(text: str) -> str:
        """Bỏ khoảng trắng và dấu '.' để chấp nhận dạng như ``100101.01001110``.

        Dạng có dấu chấm là cách viết X.Y.Z trong slide của môn học.
        """
        if not isinstance(text, str):
            raise TypeError("Chuỗi bit phải là kiểu str")
        return "".join(text.split()).replace(".", "")

    @staticmethod
    def _validate_binary_string(binary_str: str, *, allow_empty: bool = False) -> str:
        if not isinstance(binary_str, str):
            raise TypeError("Chuỗi bit phải là kiểu str")

        value = binary_str.strip()
        if not value and not allow_empty:
            raise ValueError("Chuỗi bit không được để trống")
        if any(char not in "01" for char in value):
            raise ValueError("Chuỗi bit chỉ được chứa ký tự '0' và '1'")
        return value

    @classmethod
    def binary_to_bytes(cls, binary_str: str) -> bytes:
        """Đổi chuỗi bit có độ dài chia hết cho 8 thành bytes (MSB trước)."""
        value = cls._validate_binary_string(binary_str)
        if len(value) % 8 != 0:
            raise ValueError(
                "Độ dài chuỗi bit phải chia hết cho 8 "
                f"(hiện có {len(value)} bit)"
            )
        return bytes(int(value[i : i + 8], 2) for i in range(0, len(value), 8))

    @classmethod
    def _binary_to_left_aligned_bytes(cls, binary_str: str) -> bytes:
        """Đóng gói chuỗi bit độ dài bất kỳ, căn trái, đệm 0 bên phải."""
        value = cls._validate_binary_string(binary_str)
        padding = (-len(value)) % 8
        return cls.binary_to_bytes(value + ("0" * padding))

    @staticmethod
    def xor_binary(left: str, right: str) -> str:
        if len(left) != len(right):
            raise ValueError("Hai chuỗi bit phải cùng độ dài để XOR")
        if any(char not in "01" for char in left + right):
            raise ValueError("Chuỗi bit chỉ được chứa ký tự '0' và '1'")
        return "".join("1" if a != b else "0" for a, b in zip(left, right))

    # ------------------------------------------------------------------
    # Khóa và số khung
    # ------------------------------------------------------------------
    @staticmethod
    def validate_key_binary(key_binary: str, expected_bits: int) -> str:
        if not isinstance(key_binary, str):
            raise KeyValidationError("Khóa phải là chuỗi bit")

        value = key_binary.strip()
        if len(value) != expected_bits:
            raise KeyValidationError(
                f"Khóa phải có đúng {expected_bits} bit "
                f"(hiện có {len(value)} bit)."
            )

        invalid_chars = sorted({char for char in value if char not in "01"})
        if invalid_chars:
            raise KeyValidationError(
                "Khóa chỉ được chứa '0' và '1'. "
                f"Ký tự không hợp lệ: {invalid_chars}"
            )
        return value

    def key_binary_to_bytes(self, algorithm_name: str, key_binary: str) -> bytes:
        """Kiểm tra khóa dạng chuỗi bit và đóng gói thành bytes cho thuật toán."""
        algo = self._get(algorithm_name)
        validated = self.validate_key_binary(key_binary, expected_bits=algo.key_bits)
        return self._binary_to_left_aligned_bytes(validated)

    def generate_key_binary(self, algorithm_name: str) -> str:
        """Sinh khóa ngẫu nhiên (khác 0) đúng độ dài của thuật toán."""
        bits = self._get(algorithm_name).key_bits
        return format(secrets.randbelow((1 << bits) - 1) + 1, f"0{bits}b")

    def validate_frame(self, algorithm_name: str, frame) -> int:
        """Kiểm tra số khung: A5/1 trong [0, 2^22), Tiny bắt buộc bằng 0."""
        algo = self._get(algorithm_name)
        if not isinstance(frame, int) or isinstance(frame, bool):
            raise FrameValidationError("Số khung phải là số nguyên")
        if algo.frame_bits == 0:
            if frame != 0:
                raise FrameValidationError(
                    f"{algo.name} không dùng số khung (phải bằng 0)"
                )
        elif not 0 <= frame < (1 << algo.frame_bits):
            raise FrameValidationError(
                f"Số khung phải nằm trong [0, {(1 << algo.frame_bits) - 1}] "
                f"({algo.frame_bits} bit)"
            )
        return frame

    @staticmethod
    def parse_frame(frame_text: str) -> int:
        """Đọc số khung từ chuỗi người dùng nhập (rỗng = 0)."""
        text = (frame_text or "").strip()
        if not text:
            return 0
        try:
            return int(text, 10)
        except ValueError as exc:
            raise FrameValidationError("Số khung phải là số nguyên thập phân") from exc

    def _prepare(self, algorithm_name: str, key_binary: str, frame):
        """Kiểm tra khóa + số khung, trả về (thuật toán, khóa bytes, số khung)."""
        algo = self._get(algorithm_name)
        key_bytes = self.key_binary_to_bytes(algorithm_name, key_binary)
        frame = self.validate_frame(algorithm_name, frame)
        return algo, key_bytes, frame

    # ------------------------------------------------------------------
    # KIỂU 1 - Nhập chuỗi bit nhị phân
    # ------------------------------------------------------------------
    def encrypt_binary(
        self, algorithm_name: str, plaintext_binary: str, key_binary: str,
        frame: int = 0,
    ) -> Dict[str, str]:
        """C = P XOR S, với P là chuỗi bit bất kỳ độ dài."""
        plaintext_binary = self._validate_binary_string(
            plaintext_binary, allow_empty=True
        )
        algo, key_bytes, frame = self._prepare(algorithm_name, key_binary, frame)
        keystream = "".join(
            str(bit)
            for bit in algo.generate_keystream(key_bytes, frame, len(plaintext_binary))
        )
        return {
            "algorithm": algorithm_name,
            "frame": str(frame),
            "plaintext_binary": plaintext_binary,
            "keystream": keystream,
            "ciphertext_binary": self.xor_binary(plaintext_binary, keystream),
        }

    def decrypt_binary(
        self, algorithm_name: str, ciphertext_binary: str, key_binary: str,
        frame: int = 0,
    ) -> Dict[str, str]:
        """P = C XOR S (cùng khóa, cùng số khung với lúc mã hóa)."""
        r = self.encrypt_binary(algorithm_name, ciphertext_binary, key_binary, frame)
        return {
            "algorithm": r["algorithm"],
            "frame": r["frame"],
            "ciphertext_binary": r["plaintext_binary"],
            "keystream": r["keystream"],
            "plaintext_binary": r["ciphertext_binary"],
        }

    # ------------------------------------------------------------------
    # KIỂU 2 - Nhập văn bản bình thường (UTF-8)
    # ------------------------------------------------------------------
    def encrypt_text(
        self, algorithm_name: str, plaintext: str, key_binary: str, frame: int = 0,
    ) -> Dict[str, str]:
        """Mã hóa văn bản UTF-8; bản mã trả về dạng bit và hex."""
        algo, key_bytes, frame = self._prepare(algorithm_name, key_binary, frame)
        plaintext_bytes = self.text_to_utf8_bytes(plaintext)

        # Keystream chỉ sinh đúng một lần cho mỗi yêu cầu.
        ciphertext_bytes, keystream_bits = algo.encrypt_with_keystream(
            plaintext_bytes, key_bytes, frame
        )
        return {
            "algorithm": algorithm_name,
            "frame": str(frame),
            "plaintext_binary": self.bytes_to_binary(plaintext_bytes),
            "keystream": "".join(str(bit) for bit in keystream_bits),
            "ciphertext_binary": self.bytes_to_binary(ciphertext_bytes),
            "ciphertext_hex": ciphertext_bytes.hex(),
        }

    def decrypt_text(
        self, algorithm_name: str, ciphertext_hex: str, key_binary: str,
        frame: int = 0,
    ) -> Dict[str, str]:
        """Giải mã từ bản mã dạng hex về văn bản UTF-8."""
        algo, key_bytes, frame = self._prepare(algorithm_name, key_binary, frame)
        try:
            ciphertext_bytes = bytes.fromhex("".join(ciphertext_hex.split()))
        except ValueError as exc:
            raise ValueError("Bản mã phải là chuỗi hex hợp lệ (0-9, a-f)") from exc

        plaintext_bytes, keystream_bits = algo.encrypt_with_keystream(
            ciphertext_bytes, key_bytes, frame
        )
        try:
            plaintext = plaintext_bytes.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError(
                "Kết quả không phải văn bản UTF-8. "
                "Hãy kiểm tra khóa, số khung và bản mã."
            ) from exc
        return {
            "algorithm": algorithm_name,
            "frame": str(frame),
            "ciphertext_hex": ciphertext_bytes.hex(),
            "ciphertext_binary": self.bytes_to_binary(ciphertext_bytes),
            "keystream": "".join(str(bit) for bit in keystream_bits),
            "plaintext_binary": self.bytes_to_binary(plaintext_bytes),
            "plaintext": plaintext,
        }

    # ------------------------------------------------------------------
    # KIỂU 3 - Nhập ký tự A..H cho Tiny A5/1 (bảng đổi ở tiny_chars.py)
    # ------------------------------------------------------------------
    def encrypt_chars(self, text: str, key_binary: str) -> Dict[str, str]:
        """Tiny A5/1: đổi chữ cái A..H thành bit (3 bit/chữ) rồi mã hóa."""
        normalized = tiny_chars.normalize_chars(text)
        result = self.encrypt_binary(
            ALGO_TINY, tiny_chars.chars_to_bits(normalized), key_binary
        )
        result["plaintext"] = normalized
        return result

    def decrypt_chars(self, ciphertext_binary: str, key_binary: str) -> Dict[str, str]:
        """Tiny A5/1: giải mã chuỗi bit rồi đổi ngược thành ký tự."""
        result = self.decrypt_binary(ALGO_TINY, ciphertext_binary, key_binary)
        result["plaintext"] = tiny_chars.bits_to_chars(result["plaintext_binary"])
        return result
