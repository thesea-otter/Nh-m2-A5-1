# -*- coding: utf-8 -*-
"""Bộ điều phối cho tab "Demo tấn công" - KHÔNG phụ thuộc Tkinter.

Đóng vai trò giống ``controller.py`` đối với ``CipherPanel``: ``attack_panel.py`` chỉ vẽ
widget và chạy luồng nền; toàn bộ việc gọi service và định dạng kết quả nằm ở đây nên có thể
kiểm thử mà không cần mở cửa sổ.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional

from service.attack_service import AttackResult, AttackService


@dataclass(frozen=True)
class AttackView:
    """Kết quả demo tấn công đã định dạng để hiển thị."""

    summary: str      # một dòng tóm tắt, dùng cho nhãn trạng thái
    detail: str        # nội dung đầy đủ hiển thị trong ô kết quả
    result: AttackResult


class AttackController:
    def __init__(self, service: Optional[AttackService] = None):
        self.service = service or AttackService()

    def run(
        self,
        real_key_binary: str,
        message: str,
        known_bits: int,
        known_suffix: str = "",
        on_progress: Optional[Callable[[int, int, float], None]] = None,
    ) -> AttackView:
        result = self.service.run(
            real_key_binary, message, known_bits, known_suffix, on_progress=on_progress
        )
        return AttackView(self._summary(result), self._detail(real_key_binary, message,
                                                               known_bits, result), result)

    # ------------------------------------------------------------------
    @staticmethod
    def _summary(result: AttackResult) -> str:
        ghi_chu = (
            " Các khóa này cho cùng một keystream."
            if result.candidates_found > 1 and result.same_keystream else ""
        )
        return (
            f"Tìm được {result.candidates_found} khóa ứng viên trong "
            f"{result.elapsed_seconds:.2f} giây (đã thử {result.total:,} khóa)." + ghi_chu
        )

    @staticmethod
    def _detail(real_key_binary: str, message: str, known_bits: int, r: AttackResult) -> str:
        parts = [
            f"Khóa thật (giấu với kẻ tấn công): {real_key_binary}",
            f"Bản rõ minh họa: {message}",
            f"Số bit bản rõ coi như đã biết trước: {known_bits}",
            "",
            f"Bản mã (bit): {r.ciphertext_binary}",
            f"Đoạn khóa dòng suy ra (S = P xor C): {r.known_keystream_binary}",
            "",
            f"Đã thử {r.tested:,}/{r.total:,} khóa trong {r.elapsed_seconds:.2f} giây.",
            f"Số khóa ứng viên còn lại: {r.candidates_found}",
            "",
        ]

        if r.skipped_verification:
            parts.append(
                "Còn quá nhiều ứng viên để kiểm tra từng khóa bằng đoạn cuối đã biết. "
                "Hãy tăng số bit đã biết trước rồi chạy lại."
            )
            return "\n".join(parts)

        parts.append(
            "Khóa ứng viên" + (" (đã lọc lại bằng đoạn cuối đã biết):" if r.verified else ":")
        )
        # Khi có nhiều khóa tương đương thì đánh dấu từng dòng là gây hiểu lầm (kẻ tấn công không
        # phân biệt được), nên chỉ giải thích bằng một thông báo bên dưới danh sách.
        nhieu_tuong_duong = r.candidates_found > 1 and bool(r.same_keystream)
        for c in r.candidates:
            danh_dau = "   <-- khóa thật" if c.is_real_key and not nhieu_tuong_duong else ""
            parts.append(f"  {c.key_binary}  ->  {c.plaintext!r}{danh_dau}")
        if r.candidates_found > len(r.candidates):
            parts.append(f"  ... còn {r.candidates_found - len(r.candidates)} khóa khác không hiển thị.")

        if r.candidates_found == 1:
            parts.append("")
            parts.append(
                "Chỉ còn đúng một khóa phù hợp: kẻ tấn công giải mã được toàn bộ bản mã mà "
                "không cần biết khóa gốc."
            )
        elif nhieu_tuong_duong:
            parts.append("")
            parts.append(
                f"{r.candidates_found} khóa cho cùng keystream; khóa thật là một trong số đó"
                f" ({real_key_binary})."
            )
            parts.append(
                "Lý do: luật clock theo đa số là hàm nhiều-về-một. Mỗi khóa trong nhóm này đứng "
                "yên một thanh ghi khác nhau ở bước đầu (hoặc cả ba cùng quay), nhưng các thanh "
                "ghi còn lại quay vào cùng một giá trị, nên các khóa hợp nhất về cùng một trạng "
                "thái và sinh keystream giống hệt nhau. Đây là đặc tính của thuật toán, không "
                "phải lỗi; kẻ tấn công không cần phân biệt vì mọi khóa đều giải ra cùng bản rõ."
            )
        elif r.candidates_found == 0:
            parts.append("")
            parts.append("Không có khóa nào khớp - kiểm tra lại dữ liệu đã nhập.")

        return "\n".join(parts)
