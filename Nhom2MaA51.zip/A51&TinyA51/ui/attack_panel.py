# -*- coding: utf-8 -*-
"""Tab "Demo tấn công": minh họa known-plaintext lên Tiny A5/1 ngay trong ứng dụng desktop.

Chỉ vẽ widget và thu dữ liệu nhập; toàn bộ xử lý nằm ở ``AttackController`` /
``AttackService``. Việc vét cạn 2**23 khóa chạy trong một luồng nền (``threading``); bên
trong luồng đó, ``AttackService`` còn dùng ``multiprocessing`` để chia việc cho nhiều lõi
CPU. Tiến độ được đẩy qua một hàng đợi (``queue.Queue``) và cửa sổ đọc hàng đợi đó bằng
``root.after``, đúng theo cách ``CipherPanel`` trong ``app.py`` đang làm với việc mã hóa.
"""

from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from service.attack_service import AttackInputError, KEY_BITS, KHOA_DEMO_MAC_DINH, TONG_SO_KHOA

from .attack_controller import AttackController, AttackView

# Bảng màu dùng riêng cho panel này, lấy cùng giá trị với app.py. Không import trực tiếp từ
# app.py để tránh vòng phụ thuộc (app.py sẽ import AttackPanel từ module này).
CARD = "#ffffff"
BORDER = "#e0e4ea"
TEXT = "#1b2230"
PRIMARY = "#1a7bff"


class AttackPanel(ttk.Frame):
    """Tab minh họa tấn công known-plaintext lên Tiny A5/1 (khóa 23 bit)."""

    def __init__(self, parent, root: tk.Tk):
        super().__init__(parent, padding=20, style="Page.TFrame")
        self.root = root
        self.controller = AttackController()
        self.messages: "queue.Queue" = queue.Queue()
        self.busy = False

        self.key = tk.StringVar(value=KHOA_DEMO_MAC_DINH)
        self.message = tk.StringVar(value="MA OTP CUA BAN LA 739215. KHONG CHIA SE MA NAY")
        self.known_bits = tk.IntVar(value=64)
        self.known_suffix = tk.StringVar(value="KHONG CHIA SE MA NAY")
        self.bits_hint = tk.StringVar()
        self.status = tk.StringVar(value="Chọn khóa và thông điệp minh họa rồi bắt đầu.")

        self._build()
        self.message.trace_add("write", self._sync_bits_range)
        self._sync_bits_range()

    # ------------------------------------------------------------------
    # Dựng giao diện
    # ------------------------------------------------------------------
    def _build(self) -> None:
        self.columnconfigure(0, minsize=340)
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        left = tk.Frame(self, background=CARD, highlightbackground=BORDER,
                        highlightthickness=1, bd=0)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 16))
        inner = ttk.Frame(left, padding=18, style="Card.TFrame")
        inner.pack(fill="both", expand=True)

        ttk.Label(inner, text="Thiết lập cuộc tấn công", style="Heading.TLabel").pack(anchor="w")
        ttk.Label(
            inner,
            text=("Kẻ tấn công không biết khóa K nhưng biết một đoạn đầu của bản rõ.\n"
                  "Minh họa áp dụng cho Tiny A5/1: khóa 23 bit nên vét cạn được toàn bộ "
                  f"{TONG_SO_KHOA:,} khóa có thể có."),
            style="Muted.TLabel", wraplength=300, justify="left",
        ).pack(anchor="w", pady=(4, 16))

        def field(label: str) -> None:
            ttk.Label(inner, text=label, style="Field.TLabel").pack(anchor="w", pady=(10, 4))

        field(f"Khóa bí mật K ({KEY_BITS} bit, chỉ dùng để tạo bản mã minh họa)")
        ttk.Entry(inner, textvariable=self.key).pack(fill="x")

        field("Thông điệp bản rõ minh họa")
        ttk.Entry(inner, textvariable=self.message).pack(fill="x")

        field("Số bit đầu của bản rõ mà kẻ tấn công coi như đã biết")
        bits_row = ttk.Frame(inner, style="Card.TFrame")
        bits_row.pack(fill="x")
        self.known_bits_spin = ttk.Spinbox(
            bits_row, from_=1, to=800, textvariable=self.known_bits,
            width=6, justify="right", command=self._clamp_known_bits,
        )
        self.known_bits_spin.pack(side="left")
        # Gõ số trực tiếp rồi bấm Tab/Enter cũng phải được kẹp lại trong giới hạn hợp lệ.
        self.known_bits_spin.bind("<FocusOut>", lambda _e: self._clamp_known_bits())
        self.known_bits_spin.bind("<Return>", lambda _e: self._clamp_known_bits())
        ttk.Label(bits_row, textvariable=self.bits_hint, style="Muted.TLabel").pack(
            side="left", padx=(10, 0))

        field("Đoạn cuối đã biết, dùng để kiểm tra lại (để trống nếu không có)")
        ttk.Entry(inner, textvariable=self.known_suffix).pack(fill="x")

        self.start_button = ttk.Button(inner, text="Bắt đầu tấn công",
                                       style="Primary.TButton", command=self.start)
        self.start_button.pack(fill="x", pady=(20, 0))

        self.progress = ttk.Progressbar(inner, style="Blue.Horizontal.TProgressbar",
                                        mode="determinate", maximum=TONG_SO_KHOA)
        self.progress.pack(fill="x", pady=(14, 4))
        ttk.Label(inner, textvariable=self.status, style="Muted.TLabel",
                 wraplength=300, justify="left").pack(anchor="w")

        right = tk.Frame(self, background=CARD, highlightbackground=BORDER,
                         highlightthickness=1, bd=0)
        right.grid(row=0, column=1, sticky="nsew")
        right_inner = ttk.Frame(right, padding=18, style="Card.TFrame")
        right_inner.pack(fill="both", expand=True)
        right_inner.rowconfigure(1, weight=1)
        right_inner.columnconfigure(0, weight=1)
        ttk.Label(right_inner, text="Diễn biến cuộc tấn công", style="Heading.TLabel").grid(
            row=0, column=0, sticky="w", pady=(0, 10))
        self.output = ScrolledText(right_inner, relief="flat", borderwidth=0,
                                   highlightthickness=1, highlightbackground=BORDER,
                                   background=CARD, foreground=TEXT, padx=14, pady=12)
        self.output.grid(row=1, column=0, sticky="nsew")
        self.output.configure(state="disabled")

    def _sync_bits_range(self, *_args) -> None:
        """Giới hạn số bit đã biết theo đúng độ dài thông điệp hiện tại (không có trần cứng)."""
        gioi_han = max(1, len(self.message.get().encode("utf-8")) * 8)
        self.known_bits_spin.configure(to=gioi_han)
        self.bits_hint.set(f"tối đa {gioi_han} bit (độ dài thông điệp hiện tại)")
        self._clamp_known_bits(gioi_han)

    def _clamp_known_bits(self, gioi_han: int | None = None) -> None:
        """Kẹp giá trị gõ vào ô Spinbox trong khoảng [1, độ dài thông điệp]."""
        if gioi_han is None:
            gioi_han = max(1, len(self.message.get().encode("utf-8")) * 8)
        try:
            value = int(self.known_bits.get())
        except (tk.TclError, ValueError):
            value = gioi_han
        self.known_bits.set(min(max(value, 1), gioi_han))

    # ------------------------------------------------------------------
    # Chạy demo tấn công trên luồng nền
    # ------------------------------------------------------------------
    def start(self) -> None:
        if self.busy:
            return
        key, message = self.key.get(), self.message.get()
        known_bits, suffix = self.known_bits.get(), self.known_suffix.get()

        self.busy = True
        self.start_button.configure(state="disabled")
        self.progress.configure(value=0)
        self._set_output("Đang vét cạn khóa, vui lòng chờ…")
        self.status.set("Đang chạy…")
        threading.Thread(target=self._worker, args=(key, message, known_bits, suffix),
                         daemon=True).start()
        self.root.after(120, self._poll)

    def _worker(self, key: str, message: str, known_bits: int, suffix: str) -> None:
        try:
            view = self.controller.run(
                key, message, known_bits, suffix,
                on_progress=lambda done, total, elapsed:
                    self.messages.put(("progress", done, total, elapsed)),
            )
            self.messages.put(("done", view))
        except AttackInputError as exc:
            self.messages.put(("error", str(exc)))
        except Exception as exc:  # lỗi không lường trước vẫn phải báo cho người dùng
            self.messages.put(("error", f"Không chạy được demo: {exc}"))

    def _poll(self) -> None:
        try:
            while True:
                kind, *payload = self.messages.get_nowait()
                if kind == "progress":
                    done, total, elapsed = payload
                    self.progress.configure(maximum=total, value=done)
                    self.status.set(f"Đã thử {done:,}/{total:,} khóa · {elapsed:.1f} giây")
                elif kind == "done":
                    self._finish(payload[0])
                    return
                elif kind == "error":
                    self._fail(payload[0])
                    return
        except queue.Empty:
            pass
        self.root.after(120, self._poll)

    def _finish(self, view: AttackView) -> None:
        self.busy = False
        self.start_button.configure(state="normal")
        self.progress.configure(value=self.progress["maximum"])
        self.status.set(view.summary)
        self._set_output(view.detail)

    def _fail(self, message: str) -> None:
        self.busy = False
        self.start_button.configure(state="normal")
        self.status.set(message)
        messagebox.showerror("Không chạy được demo", message, parent=self.root)

    def _set_output(self, text: str) -> None:
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)
        self.output.configure(state="disabled")

    def shutdown(self) -> None:
        """Gọi khi đóng ứng dụng, để khớp với App.close() lặp qua self.panels."""