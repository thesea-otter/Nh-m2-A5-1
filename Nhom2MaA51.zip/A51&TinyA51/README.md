# A5/1 & Tiny A5/1 — Mã hóa và giải mã (bản final)

Ứng dụng desktop (Python + Tkinter) cùng phần backend tự cài đặt **A5/1 đầy đủ**
và **Tiny A5/1 (23 bit)**. Chỉ dùng thư viện chuẩn của Python, chạy offline.

> **Lưu ý:** A5/1 là thuật toán cũ và Tiny A5/1 là mô hình giảng dạy. Đây là bài
> tập học thuật, không dùng để bảo vệ dữ liệu thật.

## Chức năng

| Tab | Kiểu đầu vào | Ghi chú |
|---|---|---|
| **A5/1 đầy đủ** | Chuỗi bit nhị phân | Khóa 64 bit, số khung 22 bit |
| | Văn bản bình thường | UTF-8; bản mã hiển thị dạng hex và bit |
| | Tải tệp `.txt` | UTF-8, tối đa 64 KiB; bản mã lưu dạng Base64 trong `.txt` |
| **Tiny A5/1** | Chuỗi bit nhị phân | Khóa 23 bit, X/Y/Z = 6/8/9 |
| | Ký tự | Chữ cái A–H, mỗi chữ 3 bit theo slide (A=000 … H=111) |

Mỗi tab đều có **Mã hóa** và **Giải mã** (mã dòng nên hai chiều là cùng một phép XOR
với keystream; khi giải mã phải dùng đúng khóa và số khung đã dùng lúc mã hóa).
Khóa có thể gõ dạng có dấu chấm như trong slide: `100101.01001110.100110000`.

## Cách chạy

Cần Python 3.9+ có Tcl/Tk (kiểm tra: `python -m tkinter`).

- Windows: nhấp đúp `start_windows.bat`
- Dòng lệnh: `python run_app.py`

Chạy test (không cần màn hình): `python -m unittest discover -s tests -v`

## Cấu trúc mã nguồn

```text
A51_Final/
├── run_app.py              # điểm khởi chạy ứng dụng
├── start_windows.bat       # nhấp đúp để chạy trên Windows
├── algorithms/             # TẦNG THUẬT TOÁN - chỉ có phần lõi mật mã
│   ├── base_cipher.py      #   lớp cơ sở: sinh keystream -> XOR
│   ├── a5_1.py             #   A5/1 đầy đủ (3 LFSR 19/22/23 bit, clock đa số)
│   └── a5_1_tiny.py        #   Tiny A5/1 (X/Y/Z = 6/8/9, khóa 23 bit)
├── service/                # TẦNG SERVICE - logic ứng dụng, không biết gì về giao diện
│   ├── cipher_service.py   #   kiểm tra khóa/số khung, mã hóa bit / văn bản / ký tự
│   ├── file_service.py     #   mã hóa/giải mã tệp .txt (Base64)
│   └── tiny_chars.py       #   bảng ký tự A–H <-> 3 bit cho Tiny
├── ui/                     # TẦNG GIAO DIỆN
│   ├── controller.py       #   điều phối: gọi service, định dạng kết quả, chọn/lưu tệp (không dùng Tk)
│   └── app.py              #   chỉ chứa widget Tkinter
├── tests/                  # 73 test (thuật toán, service, tệp, controller)
└── examples/tieng_viet.txt # tệp mẫu để thử chức năng tải tệp
```

Quy tắc phụ thuộc một chiều: `ui` → `service` → `algorithms`. Giao diện không chứa
thuật toán; thuật toán không biết đến giao diện hay tệp.

## Dùng backend độc lập (không cần giao diện)

```python
from service import CipherService, FileCipherService

svc = CipherService()

# 1) Chuỗi bit - ví dụ Tiny trong slide: P=111 -> C=011
svc.encrypt_binary("a5/1-tiny", "111", "10010101001110100110000")

# 2) Văn bản - A5/1 đầy đủ, khóa 64 bit, số khung 7
key = svc.generate_key_binary("a5/1")
enc = svc.encrypt_text("a5/1", "Xin chào", key, frame=7)
svc.decrypt_text("a5/1", enc["ciphertext_hex"], key, frame=7)["plaintext"]

# 3) Tệp .txt
files = FileCipherService(svc)
with open("examples/tieng_viet.txt", "rb") as f:
    result = files.encrypt_file(f, "tieng_viet.txt", key, "a5/1", frame=7)
result.data      # bytes Base64 để ghi ra tệp
```

## Chế độ Ký tự của Tiny A5/1

Theo bảng trong slide, bản rõ là các chữ cái A–H, mỗi chữ biểu diễn bằng 3 bit:
`A=000 B=001 C=010 D=011 E=100 F=101 G=110 H=111` (ví dụ `HEAD` → `111100000011`).
Chữ thường được tự đổi thành chữ hoa, khoảng trắng bị bỏ, ký tự ngoài A–H bị từ chối.
Khi giải mã, bản mã là chuỗi bit có độ dài chia hết cho 3. Bảng nằm ở `CHAR_TO_BITS`
trong `service/tiny_chars.py` nếu cần sửa.

## Thông số thuật toán

- **A5/1 đầy đủ:** khóa 64 bit, số khung 22 bit; R1/R2/R3 = 19/22/23 bit; bit clock
  8/10/10; tap phản hồi R1 `{13,16,17,18}`, R2 `{20,21}`, R3 `{7,20,21,22}`;
  100 vòng trộn sau khi nạp khóa và số khung. Có test known-answer theo
  Briceno, Goldberg & Wagner (1999).
- **Tiny A5/1:** khóa 23 bit `K = X‖Y‖Z`; clock theo `maj(x1, y3, z3)`; ngõ ra
  `x5 ⊕ y7 ⊕ z8`; không dùng số khung. Có test ví dụ trên lớp (`111 ⊕ 100 = 011`).

## Demo tấn công: vì sao đôi khi còn nhiều hơn một khóa ứng viên

Luật clock theo đa số của Tiny A5/1 (và A5/1 thật): thanh ghi nào có bit điều khiển
**bằng** `maj(x1, y3, z3)` thì quay. Nếu 3 bit điều khiển bằng nhau thì **cả 3** thanh ghi
cùng quay; nếu chỉ 2 bằng nhau thì 2 thanh ghi quay, thanh ghi lệch đứng yên.

Hệ quả: bước dịch có điều kiện là hàm nhiều-về-một. Nhiều khóa khác nhau có thể hợp nhất về
cùng một trạng thái `(X, Y, Z)` sau một bước, từ đó keystream giống hệt nhau và bản mã giải
ra cùng một bản rõ. Khi demo báo "N khóa cho cùng keystream; khóa thật là một trong số đó"
thì đây là đặc tính của thuật toán chứ không phải lỗi cài đặt, và không thể phân biệt các
khóa này bằng thêm bản rõ (chỉ phân biệt được bằng thông tin khác về khóa). Có thể kiểm
chứng bằng `attacks.trang_thai_sau(k, 1)` (trạng thái sau 1 bước) và đếm số khóa tương đương
bằng `attacks.dem_khoa_tuong_duong(k, n)` (cần một lần vét cạn, vài giây).

## Giới hạn cần biết

- Tệp bản mã **không chứa** khóa, thuật toán hay số khung và không có kiểm tra
  toàn vẹn. Khóa/số khung sai có thể cho ra lỗi UTF-8 hoặc văn bản vô nghĩa mà
  chương trình không phát hiện được.
- Bản A5/1 trong gói này là A5/1 đầy đủ (có số khung và vòng trộn), **khác** bản
  mô phỏng 64 bit chia khóa 19/22/23 trong gói desktop cũ; vì vậy tệp Base64 tạo
  từ gói cũ **không** giải mã được bằng gói này.
